"""⑤ 游戏化 Agent (Gamification).

把静态叙事节点转成可玩游戏：布 choices / 挂 minigame / 设 endings / 挂数值点。

v1.2 起：
- Choice.requires 生成为结构化 Condition AST（不再是字符串）
- Ending.unlock 生成为 And_(VarCmp, VarCmp)
- 为部分选择埋 gain_items / consume_items，串起 v1.2 的道具系统
- 生成道具池挂到 skeleton 里，供 direction/structurer 汇总到 Assets.items
"""

from __future__ import annotations

from typing import List

from pydantic import BaseModel

from ..config import PipelineConfig
from ..llm import LLMRouter
from ..models import (
    And_,
    Choice,
    Condition,
    Ending,
    Item,
    Minigame,
    Node,
    StorySetting,
    StorySkeleton,
    VarCmp,
)
from ..prompts import GAMIFICATION_SYSTEM


class _GamifiedResponse(BaseModel):
    nodes: List[Node]
    endings: List[Ending]
    items: List[Item] = []


def run_gamification(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    nodes: List[Node],
    router: LLMRouter,
) -> tuple[List[Node], List[Ending], List[Item]]:
    node_dump = [n.model_dump() for n in nodes]
    user_msg = (
        f"变量表：{skeleton.variables}\n"
        f"分支：\n" + "\n".join(f"- {b.id}: {b.label} → {b.ending_direction}" for b in skeleton.branches)
        + "\n\n以下是所有节点，请为它们加上 choices/minigame/type 字段，并为每条分支追加一个 ending 节点：\n"
        + str(node_dump)
        + "\n\nv1.2 要求：\n"
        + "- Choice.requires 与 Ending.unlock 必须使用结构化 Condition AST（type=var_cmp/has_item/and/or/not）。\n"
        + "- 关键道具挂到 gain_items / consume_items / requires_items 字段。\n"
        + "- 也请返回 items 数组：本剧本使用的所有 Item（id/name/type/description）。\n"
        + "- 变量名严格与变量表一致；道具 ID 严格与 items 数组一致。"
    )
    resp = router.chat_json(
        role="gamification",
        messages=[
            {"role": "system", "content": GAMIFICATION_SYSTEM},
            {"role": "user", "content": user_msg},
        ],
        schema=_GamifiedResponse,
    )
    return resp.nodes, resp.endings, resp.items


def _make_var_cmp_condition(pairs: list[tuple[str, str, int]]) -> Condition:
    """把 (var, op, value) 三元组列表打包成 And_(VarCmp, ...)。

    v1.2 Gamification 生成的解锁条件几乎都是「几个变量同时满足阈值」，
    用 And_ 作为顶层是最自然的形式；如果只有一个 VarCmp 则直接返回。
    """
    parts = [VarCmp(var=v, op=op, value=val) for v, op, val in pairs]  # type: ignore[arg-type]
    if len(parts) == 1:
        return parts[0]
    return And_(conditions=parts)


def mock_gamification(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    nodes: List[Node],
) -> tuple[List[Node], List[Ending], List[Item]]:
    """规则占位：按分支追加 choices，插入若干 minigame，为每条分支收一个 ending 节点。

    v1.2：所有 requires/unlock 均直接构造为 Condition AST；埋若干 gain_items 演示道具系统。
    """
    var_names = list(skeleton.variables.keys()) or ["好感度", "勇气"]
    branch_id_to_nodes: dict[str, list[Node]] = {}
    for n in nodes:
        if n.branch_id:
            branch_id_to_nodes.setdefault(n.branch_id, []).append(n)

    endings: List[Ending] = []
    new_nodes: List[Node] = []
    items: List[Item] = []

    branches = skeleton.branches
    for bi, branch in enumerate(branches):
        # 每条分支产出一件「关键道具」——从分支 key_props 里取第一个（或用兜底名）
        prop_name = branch.key_props[0] if branch.key_props else f"信物{bi + 1}"
        item_id = f"i_{branch.id}_key"
        items.append(
            Item(
                id=item_id,
                name=prop_name,
                type="key_item",
                stackable=False,
                description=f"分支「{branch.label}」的关键道具，触发结局解锁使用",
            )
        )
        # 再补一个通用消耗品，供 consume 演示
        potion_id = f"i_{branch.id}_potion"
        items.append(
            Item(
                id=potion_id,
                name=f"{branch.label}·勇气丹",
                type="consumable",
                stackable=True,
                description="临时提升勇气数值 5 点的消耗品",
            )
        )

        b_nodes = branch_id_to_nodes.get(branch.id, [])
        if not b_nodes:
            continue

        # 中段第一个节点埋一个 gain_items —— 让玩家先拿到 key_item
        if len(b_nodes) >= 2:
            b_nodes[1].gain_items = [item_id]

        # 追加 ending 节点
        ending_id = f"n_{branch.id}_end"
        ending_content = f"【{branch.label} · 结局】{branch.ending_direction}。"

        for i, node in enumerate(b_nodes):
            if i == len(b_nodes) - 1:
                # 末段选择：坚持推进到结局（需要持有 key_item）
                node.choices = [
                    Choice(
                        text=f"坚持{branch.label}",
                        effects={var_names[0]: 5, var_names[1 % len(var_names)]: 3},
                        goto=ending_id,
                        # v1.2：需要持有本分支的关键道具
                        requires=_make_var_cmp_condition(
                            [(var_names[0], ">=", 5)]
                        ),
                        requires_items=[item_id],
                        gain_items=[],
                        consume_items=[],
                    )
                ]
                # 关键节点插 minigame
                node.minigame = Minigame(
                    type="timed_click",
                    window_ms=900,
                    on_success=ending_id,
                    reward={var_names[1 % len(var_names)]: 3},
                )
            else:
                next_id = b_nodes[i + 1].id
                cross_branch = branches[(bi + 1) % len(branches)]
                cross_target = branch_id_to_nodes.get(cross_branch.id, [])
                cross_goto = cross_target[i + 1].id if len(cross_target) > i + 1 else next_id
                choices = [
                    Choice(
                        text="沿原路推进",
                        effects={var_names[0]: 3},
                        goto=next_id,
                    ),
                    Choice(
                        text=f"改走「{cross_branch.label}」路线",
                        effects={var_names[1 % len(var_names)]: 4, var_names[0]: -2},
                        goto=cross_goto,
                    ),
                ]
                # 中段第一次分岔埋一个「消耗药水换奖励」的第三选项，演示 consume_items
                if i == 0 and len(var_names) >= 2:
                    choices.append(
                        Choice(
                            text=f"服下{branch.label}·勇气丹强攻",
                            effects={var_names[1 % len(var_names)]: 5},
                            goto=next_id,
                            requires_items=[potion_id],
                            consume_items=[potion_id],
                        )
                    )
                node.choices = choices
            new_nodes.append(node)

        new_nodes.append(
            Node(
                id=ending_id,
                type="ending",
                branch_id=branch.id,
                content=ending_content,
                emotion_intensity=0.9,
                act_id="act_3",
            )
        )

        # v1.2：unlock 直接构造为 Condition AST
        threshold_a = 30 + bi * 15
        threshold_b = 20 + bi * 10
        endings.append(
            Ending(
                id=f"e_{branch.id}",
                branch_id=branch.id,
                title=f"{branch.label}结局",
                unlock=_make_var_cmp_condition(
                    [
                        (var_names[0], ">=", threshold_a),
                        (var_names[1 % len(var_names)], ">=", threshold_b),
                    ]
                ),
                is_true_ending=(bi == 0),
            )
        )

    return new_nodes, endings, items
