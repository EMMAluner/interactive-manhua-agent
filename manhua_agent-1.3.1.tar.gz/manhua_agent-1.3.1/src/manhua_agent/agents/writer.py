"""③ 写作 Agent (Writer).

按分支逐条展开节点，避免整篇一次写；每次生成时把已生成的其他分支摘要作为
「显式差异化约束」加进 prompt，落实文档 4.3 第 2 条。

v1.3：
- 额外强调「镜头感 + 低成本成片友好」：单节点只表达一个核心动作/情绪推进；
- 针对便宜模型，给出更硬的结构化提示，减少空泛抒情与世界观复读；
- 引入题材风格 brief，让同一套 Writer 对不同题材也能写出明显差异。
"""

from __future__ import annotations

from typing import List

from pydantic import BaseModel

from ..config import PipelineConfig
from ..llm import LLMRouter
from ..models import BranchSkeleton, Node, NodeType, StorySetting, StorySkeleton
from ..prompts import WRITER_SYSTEM


class _NodesResponse(BaseModel):
    """LLM 返回的 nodes 包装。"""

    nodes: List[Node]


def run_writer(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    router: LLMRouter,
) -> List[Node]:
    """逐分支生成节点。前置分支摘要作为差异化约束注入下一分支 prompt。"""

    all_nodes: List[Node] = []
    prior_summaries: List[str] = []
    style_brief = _story_style_brief(setting)
    for branch in skeleton.branches:
        diff_hint = "、".join(prior_summaries) if prior_summaries else "（无）"
        chapter_hint = (
            f"分支归属：act={branch.act_id}, chapters={branch.chapter_ids}\n"
            if branch.act_id or branch.chapter_ids
            else ""
        )
        length_constraint = (
            "\n\n"
            f"请将完整剧本控制在 {config.target_length} 字以内，必须写完整故事（有开头、发展、结局），不得因字数限制而写到一半截断。\n"
            "如果故事过长无法在限制内完成，请优先减少支线绕路、次要对白轮次和解释性旁白，保留主线完整性。"
            if config.mode == "keywords"
            else ""
        )

        user_msg = (
            f"作品：《{setting.title}》。请为分支 [{branch.id}] {branch.label} 展开节点。\n\n"
            f"题材风格 brief：{style_brief}\n"
            f"{chapter_hint}"
            f"分支冲突源：{branch.conflict_source}\n"
            f"分支结局走向：{branch.ending_direction}\n"
            f"关键道具：{', '.join(branch.key_props) or '无'}\n"
            f"节拍大纲：\n" + "\n".join(f"- {b}" for b in branch.beats) + "\n\n"
            f"**差异化硬约束**：本分支必须显著区别于以下已生成支线的：冲突源/结局/关键道具/关键桥段。\n"
            f"已生成支线摘要：{diff_hint}\n\n"
            "写作落地要求：\n"
            "- 每个节点只写一个核心推进，不要在一段里塞太多事件；\n"
            "- 每段必须让人看见画面：谁在做什么、处于什么空间、气氛如何变化；\n"
            "- 对话用口语化表达，避免文学腔空话；\n"
            "- 尽量让 1-2 个角色完成本段冲突，方便后续素材生成保持稳定。\n\n"
            f"v1.2 要求：\n"
            f"- 逐条节拍展开为节点，每个节点 60-150 字，标注 emotion_intensity。\n"
            f"- 请填 act_id/chapter_id/segment_order（本分支内节点顺序 1..N）。\n"
            f"- 节点 type 可选：dialogue / narration / inner_monologue / system / status_change。\n"
            f"  首末段偏 narration，中段可 dialogue 或 inner_monologue，涉及数值变化用 status_change。\n"
            f"- 不生成 choice/ending/minigame——那是游戏化 Agent 的活。"
            f"{length_constraint}"
        )
        temperature = router.settings.temperature_creative
        resp = router.chat_json(
            role="writer",
            messages=[
                {"role": "system", "content": WRITER_SYSTEM},
                {"role": "user", "content": user_msg},
            ],
            schema=_NodesResponse,
            temperature=temperature,
        )
        for node in resp.nodes:
            node.branch_id = branch.id
            if not node.act_id and branch.act_id:
                node.act_id = branch.act_id
        all_nodes.extend(resp.nodes)
        prior_summaries.append(f"[{branch.id}] {branch.label}: {branch.ending_direction}")
    return all_nodes


def _story_style_brief(setting: StorySetting) -> str:
    """把题材、时代、地点、关系张力压成一段短 brief，帮助低成本模型稳定发挥。"""

    wv = setting.worldview
    genre = " / ".join(setting.genre[:4]) if setting.genre else "剧情"
    cast = "；".join(f"{c.name}:{c.persona}" for c in setting.characters[:3])
    parts = [
        f"题材={genre}",
        f"时代={wv.era or '未定'}",
        f"地点={wv.location or '未定'}",
        f"主冲突={setting.main_conflict}",
    ]
    if cast:
        parts.append(f"人物张力={cast}")
    return "；".join(parts)


def _guess_content_type(idx: int, total: int) -> NodeType:
    """v1.2：根据节拍位置猜测内容类型。

    首段 narration（引入）；末段 narration（收束）；中段偶数 inner_monologue、
    奇数 dialogue——多样性优先，让前端渲染切分能力有用武之地。
    """
    if idx == 1:
        return "narration"
    if idx == total:
        return "narration"
    return "dialogue" if idx % 2 == 1 else "inner_monologue"


def mock_writer(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
) -> List[Node]:
    """规则占位：为每个节拍生成一段样板文本；v1.2 补齐幕/章/段与内容类型。"""
    nodes: List[Node] = []
    protagonist = setting.characters[0].name if setting.characters else "主角"
    tone = _story_style_brief(setting)
    for branch in skeleton.branches:
        total = len(branch.beats)
        intro_chapter = branch.chapter_ids[0] if branch.chapter_ids else None
        climax_chapter = (
            branch.chapter_ids[-1] if branch.chapter_ids else intro_chapter
        )
        for idx, beat in enumerate(branch.beats, 1):
            emotion = min(0.3 + idx * 0.12, 0.95)
            ctype = _guess_content_type(idx, total)
            chapter_id = climax_chapter if idx == total else intro_chapter
            act_id = branch.act_id or ("act_3" if idx == total else "act_2")
            character = protagonist if ctype in ("dialogue", "inner_monologue") else None
            nodes.append(
                Node(
                    id=f"n_{branch.id}_{idx:02d}",
                    type=ctype,
                    branch_id=branch.id,
                    character=character,
                    content=(
                        f"【{branch.label} · 第{idx}段】{beat}。"
                        f"{protagonist}在这一刻被迫做出更明确的选择，"
                        f"场面语气贴近{tone.split('；')[0]}，并把压力推向{branch.ending_direction}。"
                    ),
                    emotion_intensity=emotion,
                    act_id=act_id,
                    chapter_id=chapter_id,
                    segment_order=idx,
                )
            )
    return nodes
