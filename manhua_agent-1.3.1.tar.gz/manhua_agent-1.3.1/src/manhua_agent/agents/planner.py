"""② 剧情规划 Agent (Story Planner).

结构先行，让分岔发生在结构层而非文字层：产出 MECE 的支线骨架 + 变量表。

v1.2 起：`BranchSkeleton` 支持挂到「幕」上（`act_id`），
`StorySkeleton` 顶层同时携带 `acts / chapters`，供下游 Writer/Structurer 使用。

对应产品文档 4.2 表格第二行 + 4.3 第 1 条「结构先行」。
"""

from __future__ import annotations

from typing import List

from ..config import PipelineConfig
from ..llm import LLMRouter
from ..models import Act, BranchSkeleton, Chapter, StorySetting, StorySkeleton
from ..prompts import PLANNER_SYSTEM


def run_planner(
    config: PipelineConfig, setting: StorySetting, router: LLMRouter
) -> StorySkeleton:
    user_msg = (
        f"作品：《{setting.title}》\n"
        f"简介：{setting.logline}\n"
        f"主要冲突：{setting.main_conflict}\n"
        f"主线大纲：\n" + "\n".join(f"- {b}" for b in setting.outline) + "\n\n"
        f"请规划 {config.branch_count} 条 MECE 支线，"
        f"每条支线给 {config.max_nodes_per_branch} 条以内的节拍大纲；"
        f"并给出 3-6 个主属性的初始值。\n\n"
        "额外要求：\n"
        "- 支线之间不仅剧情不同，题材气质和视觉母题也要不同，方便后续生成个性化成片；\n"
        "- beats 必须具体到‘什么人、在什么场景、做什么选择’，不要写成空泛概念；\n"
        "- 尽量让多个 beats 复用少数核心场景，提高素材复用率和低成本模型稳定性。\n\n"
        f"v1.2 要求：\n"
        f"- 请给出全局的「幕」结构（3 幕：起势/承转/合），每条分支挂到某一幕上。\n"
        f"- 允许把关键分岔章节挂到 chapters 数组（可选）。\n"
        f"- 变量名与后续 Condition AST 一致（避免变量名拼写变体）。"
    )
    return router.chat_json(
        role="planner",
        messages=[
            {"role": "system", "content": PLANNER_SYSTEM},
            {"role": "user", "content": user_msg},
        ],
        schema=StorySkeleton,
    )


def _default_acts() -> List[Act]:
    """默认 3 幕结构：对齐传统剧本三幕法。"""
    return [
        Act(id="act_1", title="起势", summary="世界与人物登场，主要冲突浮现"),
        Act(id="act_2", title="承转", summary="冲突升级，各方立场明确，产生关键抉择"),
        Act(id="act_3", title="合", summary="冲突解决 / 结局分化"),
    ]


def mock_planner(config: PipelineConfig, setting: StorySetting) -> StorySkeleton:
    """规则占位：v1.2 起同时生成幕/章骨架。"""
    templates = [
        ("b_truth", "追寻真相", "内部背叛", "揭露真相后独自承担代价", ["证据", "旧信件"]),
        ("b_love", "情感抉择", "爱人身份存疑", "选择相信爱人，共同流亡", ["定情信物"]),
        ("b_revenge", "复仇之路", "同伴的死亡", "以暴制暴反被吞噬", ["武器", "复仇名单"]),
        ("b_redeem", "救赎他人", "反派也有苦衷", "感化反派达成和解", ["旧照片"]),
        ("b_escape", "全身而退", "势力过于强大", "放下执念远走他乡", ["车票"]),
        ("b_sacrifice", "自我牺牲", "两难抉择", "牺牲自己保护他人", ["遗书"]),
    ]
    acts = _default_acts()
    branches: List[BranchSkeleton] = []
    chapters: List[Chapter] = []
    for i in range(config.branch_count):
        bid, label, conflict, ending, props = templates[i % len(templates)]
        # 分支挂到 act_2「承转」（中段冲突是分支产生的位置）；起势与合分别是所有分支的共享入口/出口
        chapter_ids = [f"c_{bid}_intro", f"c_{bid}_climax"]
        chapters.append(
            Chapter(id=chapter_ids[0], act_id="act_2", title=f"{label} · 引入")
        )
        chapters.append(
            Chapter(id=chapter_ids[1], act_id="act_3", title=f"{label} · 高潮")
        )
        branches.append(
            BranchSkeleton(
                id=bid,
                label=label,
                conflict_source=conflict,
                ending_direction=ending,
                key_props=props,
                beats=[
                    f"引入：主角因{conflict}陷入被动局面",
                    "深入：搜集线索，接触关键人物",
                    "转折：出现意料之外的抉择时刻",
                    "推进：主角承受抉择带来的代价",
                    f"高潮：{ending}前的最终对峙",
                    f"结局：{ending}",
                ][: config.max_nodes_per_branch],
                act_id="act_2",
                chapter_ids=chapter_ids,
            )
        )
    # 顶层通用「起势」章
    chapters.insert(0, Chapter(id="c_prologue", act_id="act_1", title="序幕"))
    return StorySkeleton(
        variables={"好感度": 0, "勇气": 10, "金钱": 100},
        branches=branches,
        choice_points=["序章末尾的立场选择", "中段的合作/背叛决定", "高潮前的行动方式"],
        acts=acts,
        chapters=chapters,
    )
