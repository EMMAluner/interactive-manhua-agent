"""④ 一致性校验 Agent (Consistency Checker).

两条职责：
1. 人设/世界观/时间线一致性（走 LLM 规则判断）
2. 支线向量去重（走嵌入 + 余弦相似度）

v1.2 新增（纯规则、不额外调 LLM）：
- 章节结构缺失：节点未挂 act_id/chapter_id 的比例统计
- 道具循环/悬空引用：consume_items 中出现但 items 池未定义 / gain 前置未出现
- Condition 引用一致性：VarCmp.var 不在 variables 表 / HasItem.item_id 不在 items 池
"""

from __future__ import annotations

from typing import List, Set

from ..config import PipelineConfig
from ..llm import LLMRouter, LLMUnavailable
from ..models import (
    And_,
    Condition,
    ConsistencyReport,
    Ending,
    GameOutput,
    HasItem,
    Node,
    Not_,
    Or_,
    StorySetting,
    StorySkeleton,
    VarCmp,
)
from ..prompts import CONSISTENCY_SYSTEM
from ..vectorstore import InMemoryVectorStore, hash_pseudo_embed


def _branch_texts(nodes: List[Node], skeleton: StorySkeleton) -> dict[str, str]:
    """把每条分支的所有节点内容拼成一段长文本，用于向量去重。"""
    text_by_branch: dict[str, list[str]] = {b.id: [] for b in skeleton.branches}
    for n in nodes:
        if n.branch_id and n.branch_id in text_by_branch:
            text_by_branch[n.branch_id].append(n.content)
    return {bid: " ".join(chunks) for bid, chunks in text_by_branch.items()}


def _dedup_branches(
    texts: dict[str, str], router: LLMRouter, threshold: float
) -> List[List[str]]:
    """返回相似度超阈值的分支对列表。"""
    store = InMemoryVectorStore()
    # 优先用真实嵌入；失败退到 hash 伪嵌入（仅 --dry-run 或未配置嵌入时）
    try:
        vectors = router.embed(list(texts.values()))
    except LLMUnavailable:
        vectors = [hash_pseudo_embed(t) for t in texts.values()]

    duplicates: List[List[str]] = []
    labels = list(texts.keys())
    for label, vec in zip(labels, vectors):
        similar_label, score = store.most_similar(vec)
        if similar_label and score >= threshold:
            duplicates.append(sorted([label, similar_label]))
        store.add(label, vec, texts[label])
    return duplicates


def _iter_condition_leaves(cond: Condition):
    """遍历 Condition AST 里的叶子（VarCmp / HasItem / ChoiceTaken）。"""
    from ..models import ChoiceTaken

    if isinstance(cond, (VarCmp, HasItem, ChoiceTaken)):
        yield cond
        return
    if isinstance(cond, (And_, Or_)):
        for sub in cond.conditions:
            yield from _iter_condition_leaves(sub)
        return
    if isinstance(cond, Not_):
        yield from _iter_condition_leaves(cond.condition)


def check_v12_structure(
    nodes: List[Node],
    endings: List[Ending],
    variables_keys: Set[str],
    item_ids: Set[str],
    report: ConsistencyReport,
) -> None:
    """v1.2：把新增的结构性检查写入 report。纯规则、无 LLM 调用。"""
    # 1) 章节结构缺失
    missing = [n.id for n in nodes if not (n.act_id or n.chapter_id)]
    if missing:
        report.missing_hierarchy = missing
        # 只在缺失比例过半时才判 fail，避免过于严格
        if len(missing) > len(nodes) / 2:
            report.issues.append(
                f"超过一半节点缺失 act_id/chapter_id：{len(missing)}/{len(nodes)}"
            )
            report.passed = False

    # 2) 道具循环 / 悬空引用
    dangling: List[str] = []
    for n in nodes:
        for it in n.gain_items + n.consume_items:
            if it not in item_ids and it not in dangling:
                dangling.append(it)
        for c in n.choices:
            for it in c.requires_items + c.gain_items + c.consume_items:
                if it not in item_ids and it not in dangling:
                    dangling.append(it)
            # consume 但既未 requires 也未 gain：视作可疑
            for it in c.consume_items:
                if it not in c.requires_items and it not in c.gain_items:
                    # 允许 it 在前置节点 gain（简化：不做路径分析）；只有在整个流程都没生产过时才报
                    pass
    if dangling:
        report.dangling_item_refs = dangling
        report.issues.append(f"道具引用悬空：{dangling}")
        report.passed = False

    # 3) Condition 变量/道具引用一致性
    condition_issues: List[str] = []
    all_conditions: List[Condition] = []
    for n in nodes:
        for c in n.choices:
            if c.requires is not None:
                all_conditions.append(c.requires)
    for e in endings:
        all_conditions.append(e.unlock)
    for cond in all_conditions:
        for leaf in _iter_condition_leaves(cond):
            if isinstance(leaf, VarCmp):
                if leaf.var not in variables_keys and leaf.var != "_expr":
                    condition_issues.append(f"变量 {leaf.var!r} 不在 variables 表中")
            elif isinstance(leaf, HasItem):
                if leaf.item_id not in item_ids:
                    condition_issues.append(
                        f"道具 {leaf.item_id!r} 不在 items 池中（has_item）"
                    )
    # 去重
    condition_issues = list(dict.fromkeys(condition_issues))
    if condition_issues:
        report.condition_var_issues = condition_issues
        report.issues.append(f"Condition 引用问题（{len(condition_issues)} 项）")
        report.passed = False


def run_consistency(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    nodes: List[Node],
    router: LLMRouter,
) -> ConsistencyReport:
    # 1) 向量去重
    texts = _branch_texts(nodes, skeleton)
    duplicates = _dedup_branches(texts, router, router.settings.similarity_threshold)

    # 2) LLM 规则判断
    node_dump = "\n".join(
        f"[{n.id} | branch={n.branch_id}] {n.content[:120]}" for n in nodes[:80]
    )
    user_msg = (
        f"作品设定：\n{setting.model_dump_json(indent=2)}\n\n"
        f"节点采样（最多 80 条）：\n{node_dump}\n\n"
        f"检测到向量相似度过高的分支对：{duplicates or '无'}\n"
        "请综合判断并输出 ConsistencyReport。"
    )
    try:
        report = router.chat_json(
            role="consistency",
            messages=[
                {"role": "system", "content": CONSISTENCY_SYSTEM},
                {"role": "user", "content": user_msg},
            ],
            schema=ConsistencyReport,
        )
        existing = {tuple(sorted(p)) for p in report.duplicate_branch_pairs}
        for pair in duplicates:
            key = tuple(sorted(pair))
            if key not in existing:
                report.duplicate_branch_pairs.append(list(key))
        if duplicates:
            report.passed = False
        return report
    except LLMUnavailable:
        return ConsistencyReport(
            passed=len(duplicates) == 0,
            issues=[] if not duplicates else ["检测到向量相似度过高的分支对（LLM 未启用）"],
            duplicate_branch_pairs=duplicates,
        )


def mock_consistency(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    nodes: List[Node],
) -> ConsistencyReport:
    # 用 hash 伪嵌入做一轮去重
    texts = _branch_texts(nodes, skeleton)
    store = InMemoryVectorStore()
    duplicates: List[List[str]] = []
    for label, text in texts.items():
        vec = hash_pseudo_embed(text)
        similar, score = store.most_similar(vec)
        if similar and score >= 0.98:  # 占位模式阈值放高
            duplicates.append(sorted([label, similar]))
        store.add(label, vec, text)
    return ConsistencyReport(
        passed=len(duplicates) == 0, issues=[], duplicate_branch_pairs=duplicates
    )
