"""① 解析 Agent (Parser).

- 输入模式 A：小说全文 → 抽取人物/世界观/主线
- 输入模式 B：关键词/主题   → 归纳为完整设定

对应产品文档 4.2 表格中的第一行。
"""

from __future__ import annotations

from typing import Optional

from ..config import PipelineConfig
from ..llm import LLMRouter
from ..models import Act, Character, StorySetting, Worldview
from ..prompts import PARSER_SYSTEM


def run_parser(config: PipelineConfig, router: LLMRouter) -> StorySetting:
    """真实 LLM 调用版本。"""
    if config.mode == "novel":
        assert config.novel_text is not None
        user_msg = (
            "以下是一部小说全文。请抽取结构化设定：\n\n"
            "----- BEGIN NOVEL -----\n"
            f"{_truncate(config.novel_text, 60000)}\n"
            "----- END NOVEL -----\n\n"
            f"用户希望标题定为：{config.title or '（未指定，请自拟）'}\n"
            "补充要求：请优先提炼成‘可分镜、可互动、可做素材’的设定，时代/地点/人物关系/核心冲突都要具体，避免抽象化总结。"
        )
    else:
        kw = "、".join(config.keywords) if config.keywords else "（未提供）"
        user_msg = (
            "用户提供了以下创作关键词，请补全成一个完整故事设定：\n"
            f"- 关键词：{kw}\n"
            f"- 主题/世界观说明：{config.theme or '（未提供，请合理补全）'}\n"
            f"- 期望标题：{config.title or '（未指定，请自拟）'}\n\n"
            "如有关键要素缺失（时代、主角、核心冲突等），请**主动补全**为最合理的假设，"
            "不要留空，避免下游 Agent 生成失败。"
            "\n请优先补全成一个‘低成本也能拍得出、画得出、玩得动’的设定：核心人物控制在少数关键角色，核心场景控制在少数高辨识地点。"
        )

    return router.chat_json(
        role="parser",
        messages=[
            {"role": "system", "content": PARSER_SYSTEM},
            {"role": "user", "content": user_msg},
        ],
        schema=StorySetting,
    )


def mock_parser(config: PipelineConfig) -> StorySetting:
    """规则占位版本，供 --dry-run 使用，不调 LLM。"""
    if config.mode == "novel":
        title = config.title or "改编自小说的互动漫剧"
        logline = "改编自用户上传小说的多分支互动漫剧游戏。"
        genre = ["剧情", "互动"]
        era = "根据原著推断"
        location = "根据原著推断"
    else:
        kw = config.keywords or ["现代", "校园"]
        title = config.title or f"{kw[0]}物语"
        logline = f"一个关于{('、'.join(kw))}的互动漫剧。"
        genre = list(kw[:3]) or ["剧情"]
        era = kw[0] if kw else "现代"
        location = "都市"

    return StorySetting(
        title=title,
        logline=logline,
        genre=genre,
        worldview=Worldview(era=era, location=location, rules=[]),
        characters=[
            Character(name="沈砚", role="男主角", persona="冷静克制、行动派", motivation="追寻真相"),
            Character(name="林深", role="女主角", persona="聪慧敏锐、有正义感", motivation="解决案件"),
            Character(name="孟秋", role="反派", persona="城府深沉的幕后黑手", motivation="维护旧秩序"),
        ],
        main_conflict="主角团在追查案件真相时，与幕后势力发生正面冲突，需在正义与代价之间抉择。",
        outline=[
            "序章：意外相遇，主角接到一桩离奇案件。",
            "调查：线索指向多个可疑对象，主角陷入抉择。",
            "转折：真相与预想相悖，同伴受伤。",
            "高潮：与反派正面对峙。",
            "尾声：不同选择带来不同结局。",
        ],
        # v1.2：幕结构占位（planner 会覆盖/扩展），此处给 setting 一个默认三幕大纲
        acts=[
            Act(id="act_1", title="起势", summary="序章：意外相遇与线索登场"),
            Act(id="act_2", title="承转", summary="调查/转折：线索交织与抉择"),
            Act(id="act_3", title="合", summary="高潮/尾声：不同选择带来不同结局"),
        ],
    )


def _truncate(text: str, limit: int) -> str:
    """截断过长的小说文本；文档第 7 章讲：超长时先做分块摘要再合并。

    本 MVP 简单截断，后续可接入分块摘要 pipeline。
    """
    if len(text) <= limit:
        return text
    head = text[: int(limit * 0.7)]
    tail = text[-int(limit * 0.3):]
    return head + "\n\n……（中间省略，仅保留头尾以适配上下文窗口）……\n\n" + tail
