"""⑥ 演出设计 Agent (Direction / Staging).

按 emotion_intensity + 用户档位约束，为每个节点分配 static / semi-dynamic / full-video，
并生成 asset_prompt（作为后续 图像/视频 生成模块的输入）。

v1.2：把 `asset_prompt` 拆解为结构化字段（scene_id/location/background/camera/bgm_id/cg_id/voiceover），
`asset_prompt` 仍作为汇总兜底保留。多个 node 复用同一 scene_id 时，
在 `Assets.scenes` 里注册去重后的 Scene 对象；BGM 也按情绪强度归档。

v1.3：演出 Agent 从「换皮主题」升级为「题材感知的视觉导演」：
- 不同题材输出明显不同的 UI 变体、舞台特效、视觉母题与 AIGC 风格锚点；
- asset_prompt 更短、更稳、更适合便宜模型；
- 无 API Key / dry-run 下，也能跑出完整的题材化演示通路。
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from pydantic import BaseModel

from ..config import PipelineConfig, StagingTier
from ..llm import LLMRouter
from ..models import (
    BGM,
    CG,
    Node,
    ParticleConfig,
    Scene,
    StorySetting,
    VisualTheme,
    Voiceover,
)
from ..prompts import DIRECTION_SYSTEM

# 用户档位与建议档位允许的最高档
_TIER_RANK = {"static": 0, "semi-dynamic": 1, "full-video": 2}


class _StagedResponse(BaseModel):
    nodes: List[Node]


def _cap_by_user_tier(suggested: StagingTier, user_max: StagingTier) -> StagingTier:
    if _TIER_RANK[suggested] <= _TIER_RANK[user_max]:
        return suggested
    return user_max


def _suggest_by_emotion(intensity: float) -> StagingTier:
    if intensity < 0.38:
        return "static"
    if intensity < 0.72:
        return "semi-dynamic"
    return "full-video"


def _suggest_bgm_id(intensity: float) -> str:
    """按情绪强度归档 BGM ID。低情绪 → 舒缓；高情绪 → 激烈。"""
    if intensity < 0.4:
        return "bgm_calm"
    if intensity < 0.7:
        return "bgm_tense"
    return "bgm_climax"


THEME_PRESETS: Dict[str, Dict] = {
    "ancient_court": {
        "theme_name": "ancient_court",
        "theme_tags": ["古风权谋", "宫廷", "章回感"],
        "visual_motifs": ["宫灯", "屏风", "金箔纹", "折扇", "朱砂印"],
        "ui_variant": "ornate",
        "stage_effect": "vignette",
        "palette": {
            "bg": "#08060e",
            "ink": "#f2ead6",
            "ink_dim": "#bcae8c",
            "text": "#f2ead6",
            "sub": "#bcae8c",
            "gold": "#e8c56b",
            "gold_deep": "#b8873a",
            "accent": "#a01e28",
            "accent2": "#5b8fd6",
            "ok": "#5fbfa8",
            "panel": "rgba(12, 9, 18, 0.82)",
            "panel_border": "rgba(232, 197, 107, 0.32)",
        },
        "scene_gradients": {
            "daily": "linear-gradient(170deg, #140a1a 0%, #2e1630 55%, #5a2a52 100%)",
            "tense": "linear-gradient(160deg, #0e0a06 0%, #2a1c0e 52%, #5a3a16 100%)",
            "climax": "linear-gradient(180deg, #1a0608 0%, #5a1410 45%, #c85a1e 100%)",
            "ending_true": "linear-gradient(160deg, #3a2508 0%, #8b6a1a 40%, #e8c56b 100%)",
            "ending_bad": "linear-gradient(180deg, #000000 0%, #33060e 60%, #8b1a1a 100%)",
            "default": "radial-gradient(ellipse at 50% 55%, #2a0d16 0%, #08060e 78%)",
        },
        "particle": {
            "type": "sakura",
            "density": 0.55,
            "color": "#f2c4d0",
            "size_min": 4,
            "size_max": 10,
            "speed": 0.7,
            "opacity": 0.75,
        },
        "font_family": '"KaiTi", "STKaiti", "Songti SC", "SimSun", "Noto Serif CJK SC", serif',
        "bgm_mood_map": {
            "calm": "古筝独奏·舒缓（宫商羽变徵）",
            "tense": "琵琶+编钟·推进（低音鼓点渐强）",
            "climax": "编钟战鼓+管乐·激烈（大鼓+唢呐冲顶）",
        },
        "image_prompt": "Chinese ancient court drama, elegant costume, cinematic lighting, refined composition, premium manhua frame",
        "video_prompt": "ancient court intrigue, slow push-in camera, dramatic sleeves and candlelight, premium vertical drama shot",
        "negative_prompt": "modern objects, neon city, extra limbs, text watermark, cheap comic style",
    },
    "republican_noir": {
        "theme_name": "republican_noir",
        "theme_tags": ["民国谍战", "复古推理", "留声机质感"],
        "visual_motifs": ["老报纸", "黄铜台灯", "雨夜电车", "胶片边框", "档案袋"],
        "ui_variant": "paper",
        "stage_effect": "film_grain",
        "palette": {
            "bg": "#0c0a08",
            "ink": "#f0e6d0",
            "ink_dim": "#a89676",
            "text": "#f0e6d0",
            "sub": "#a89676",
            "gold": "#c8a862",
            "gold_deep": "#8a6b32",
            "accent": "#8b3a2a",
            "accent2": "#4a7ca8",
            "ok": "#8ab070",
            "panel": "rgba(18, 14, 10, 0.85)",
            "panel_border": "rgba(200, 168, 98, 0.28)",
        },
        "scene_gradients": {
            "daily": "linear-gradient(170deg, #120e0a 0%, #2a2018 55%, #4a3826 100%)",
            "tense": "linear-gradient(165deg, #0a0806 0%, #241a12 52%, #4a2818 100%)",
            "climax": "linear-gradient(180deg, #1a0a06 0%, #4a1a10 45%, #a04820 100%)",
            "ending_true": "linear-gradient(160deg, #2a1e08 0%, #6a4e18 40%, #c8a862 100%)",
            "ending_bad": "linear-gradient(180deg, #050403 0%, #2a0e08 60%, #5a1e10 100%)",
            "default": "radial-gradient(ellipse at 50% 55%, #241a10 0%, #0a0806 78%)",
        },
        "particle": {
            "type": "dust",
            "density": 0.4,
            "color": "#d8b878",
            "size_min": 1,
            "size_max": 3,
            "speed": 0.5,
            "opacity": 0.5,
        },
        "font_family": '"Songti SC", "KaiTi", "Times New Roman", serif',
        "bgm_mood_map": {
            "calm": "老式留声机·萨克斯（爵士舒缓）",
            "tense": "低音提琴+钢琴·推进（悬疑爵士）",
            "climax": "铜管+定音鼓·激烈（谍战交响）",
        },
        "image_prompt": "Republican China noir, old Shanghai mood, sepia film still, detective drama, premium illustrated frame",
        "video_prompt": "1930s noir suspense, smoky room, rain window reflection, handheld cinematic vertical shot",
        "negative_prompt": "modern LED screen, sci-fi armor, anime chibi, watermark, overexposed light",
    },
    "modern_urban": {
        "theme_name": "modern_urban",
        "theme_tags": ["现代都市", "情绪电影感", "通勤霓光"],
        "visual_motifs": ["落地窗", "街灯反射", "地铁站", "咖啡杯", "手机通知"],
        "ui_variant": "glass",
        "stage_effect": "soft_glow",
        "palette": {
            "bg": "#101418",
            "ink": "#f5f7fa",
            "ink_dim": "#95a1b3",
            "text": "#f5f7fa",
            "sub": "#95a1b3",
            "gold": "#ffd66e",
            "gold_deep": "#c9a842",
            "accent": "#ff5c8a",
            "accent2": "#5c9dff",
            "ok": "#46d39a",
            "panel": "rgba(24, 28, 34, 0.78)",
            "panel_border": "rgba(255, 255, 255, 0.14)",
        },
        "scene_gradients": {
            "daily": "linear-gradient(170deg, #182028 0%, #1e2a3a 55%, #2c4258 100%)",
            "tense": "linear-gradient(165deg, #1a1418 0%, #3a2030 55%, #6a3050 100%)",
            "climax": "linear-gradient(180deg, #2a0a20 0%, #6a1a48 45%, #ff5c8a 100%)",
            "ending_true": "linear-gradient(160deg, #0e2418 0%, #1e5a3e 40%, #46d39a 100%)",
            "ending_bad": "linear-gradient(180deg, #08080c 0%, #1a1a24 60%, #2a2a40 100%)",
            "default": "radial-gradient(ellipse at 50% 55%, #1a2028 0%, #0a0c10 78%)",
        },
        "particle": {
            "type": "dust",
            "density": 0.35,
            "color": "#ffffff",
            "size_min": 1,
            "size_max": 2,
            "speed": 0.5,
            "opacity": 0.35,
        },
        "font_family": '"PingFang SC", "Microsoft YaHei", "Segoe UI", system-ui, sans-serif',
        "bgm_mood_map": {
            "calm": "钢琴+弦乐·舒缓（都市抒情）",
            "tense": "电子鼓+合成器·推进（Lo-fi Beat）",
            "climax": "全乐队+主唱·激烈（流行摇滚）",
        },
        "image_prompt": "modern urban drama, realistic lighting, stylish city night, premium vertical comic frame, emotional close-up",
        "video_prompt": "urban emotional drama, neon reflection, smooth dolly shot, premium short drama pacing",
        "negative_prompt": "ancient costume, armor, fantasy rune, watermark, extra fingers",
    },
    "scifi_neon": {
        "theme_name": "scifi_neon",
        "theme_tags": ["赛博科幻", "高对比霓虹", "界面感"],
        "visual_motifs": ["HUD 光栅", "全息屏", "雨夜霓虹", "机械义体", "故障闪烁"],
        "ui_variant": "neon",
        "stage_effect": "scanline",
        "palette": {
            "bg": "#04081a",
            "ink": "#e6f7ff",
            "ink_dim": "#8fa8c8",
            "text": "#e6f7ff",
            "sub": "#8fa8c8",
            "gold": "#00e6ff",
            "gold_deep": "#008fb3",
            "accent": "#ff2e88",
            "accent2": "#7a3cff",
            "ok": "#00ff9d",
            "panel": "rgba(6, 12, 32, 0.78)",
            "panel_border": "rgba(0, 230, 255, 0.32)",
        },
        "scene_gradients": {
            "daily": "linear-gradient(170deg, #04081a 0%, #0e1a42 55%, #1e2e6a 100%)",
            "tense": "linear-gradient(165deg, #08041a 0%, #2a0e4a 55%, #5a1e88 100%)",
            "climax": "linear-gradient(180deg, #04081a 0%, #4a0e5a 45%, #ff2e88 100%)",
            "ending_true": "linear-gradient(160deg, #06121a 0%, #0e4a5a 40%, #00e6ff 100%)",
            "ending_bad": "linear-gradient(180deg, #000004 0%, #0a0018 60%, #2a0028 100%)",
            "default": "radial-gradient(ellipse at 50% 55%, #0e1a42 0%, #04081a 78%)",
        },
        "particle": {
            "type": "starfield",
            "density": 0.7,
            "color": "#8fe8ff",
            "size_min": 1,
            "size_max": 2.5,
            "speed": 0.4,
            "opacity": 0.9,
        },
        "font_family": '"Orbitron", "Exo 2", "PingFang SC", "Microsoft YaHei", sans-serif',
        "bgm_mood_map": {
            "calm": "合成器 pad·舒缓（Ambient Synthwave）",
            "tense": "808 + Arpeggio·推进（Cyberpunk Beat）",
            "climax": "大编制电子+失真吉他·激烈（Neo-Trance Climax）",
        },
        "image_prompt": "cyberpunk sci-fi, neon magenta and cyan, cinematic anime realism, premium UI panel look, vertical frame",
        "video_prompt": "cyberpunk chase, scanline hud, neon rain, fast cut vertical drama camera",
        "negative_prompt": "ancient palace, medieval armor, watercolor pastel, watermark, blurry face",
    },
    "mystery_noir": {
        "theme_name": "mystery_noir",
        "theme_tags": ["悬疑惊悚", "冷峻调查", "心理压迫"],
        "visual_motifs": ["手电光束", "旧案卷宗", "深夜走廊", "监控噪点", "血迹红线"],
        "ui_variant": "noir",
        "stage_effect": "vignette",
        "palette": {
            "bg": "#08080a",
            "ink": "#e0dcd0",
            "ink_dim": "#8a8578",
            "text": "#e0dcd0",
            "sub": "#8a8578",
            "gold": "#c9a35d",
            "gold_deep": "#8a6b32",
            "accent": "#c8393a",
            "accent2": "#4a5a6a",
            "ok": "#7ab070",
            "panel": "rgba(10, 8, 8, 0.86)",
            "panel_border": "rgba(200, 57, 58, 0.22)",
        },
        "scene_gradients": {
            "daily": "linear-gradient(170deg, #0a0a0c 0%, #1a1a20 55%, #2a2a34 100%)",
            "tense": "linear-gradient(165deg, #08060a 0%, #241a20 55%, #4a2830 100%)",
            "climax": "linear-gradient(180deg, #06040a 0%, #2a0810 45%, #c8393a 100%)",
            "ending_true": "linear-gradient(160deg, #14140a 0%, #3a3a1e 40%, #c9a35d 100%)",
            "ending_bad": "linear-gradient(180deg, #000000 0%, #1a0004 60%, #4a0810 100%)",
            "default": "radial-gradient(ellipse at 50% 55%, #14141a 0%, #06060a 78%)",
        },
        "particle": {
            "type": "dust",
            "density": 0.25,
            "color": "#8a8578",
            "size_min": 1,
            "size_max": 2,
            "speed": 0.3,
            "opacity": 0.35,
        },
        "font_family": '"Times New Roman", "Songti SC", "KaiTi", serif',
        "bgm_mood_map": {
            "calm": "钢琴独奏·压抑舒缓",
            "tense": "弦乐震音+钟摆音效·悬疑推进",
            "climax": "大提琴+定音鼓·惊悚爆发",
        },
        "image_prompt": "mystery noir thriller, dim corridor, focused flashlight, cinematic suspense frame, premium dark comic",
        "video_prompt": "suspense thriller, tight close-up, breathing camera, eerie corridor, vertical cinematic shot",
        "negative_prompt": "cute bright anime, festive colors, futuristic neon, watermark, low detail face",
    },
    "xuanhuan_immortal": {
        "theme_name": "xuanhuan_immortal",
        "theme_tags": ["玄幻仙侠", "灵气流动", "空灵史诗"],
        "visual_motifs": ["云海", "法阵", "玉阶", "流萤", "剑光"],
        "ui_variant": "ethereal",
        "stage_effect": "mist",
        "palette": {
            "bg": "#0b0a1e",
            "ink": "#eae4ff",
            "ink_dim": "#a89ecf",
            "text": "#eae4ff",
            "sub": "#a89ecf",
            "gold": "#c9a2f5",
            "gold_deep": "#7c5cff",
            "accent": "#7c5cff",
            "accent2": "#46d39a",
            "ok": "#8affc6",
            "panel": "rgba(14, 12, 32, 0.78)",
            "panel_border": "rgba(201, 162, 245, 0.28)",
        },
        "scene_gradients": {
            "daily": "linear-gradient(170deg, #0e0c22 0%, #1e1a4a 55%, #3a2e7a 100%)",
            "tense": "linear-gradient(165deg, #08061a 0%, #2a1a4a 55%, #5a3aa0 100%)",
            "climax": "linear-gradient(180deg, #0a0620 0%, #4a1e88 45%, #c9a2f5 100%)",
            "ending_true": "linear-gradient(160deg, #0e2a1e 0%, #1e6a4a 40%, #8affc6 100%)",
            "ending_bad": "linear-gradient(180deg, #04041a 0%, #14042a 60%, #2a0e4a 100%)",
            "default": "radial-gradient(ellipse at 50% 55%, #1a1440 0%, #0b0a1e 78%)",
        },
        "particle": {
            "type": "ember",
            "density": 0.5,
            "color": "#c9a2f5",
            "size_min": 1.5,
            "size_max": 3.5,
            "speed": 0.6,
            "opacity": 0.8,
        },
        "font_family": '"KaiTi", "STKaiti", "Songti SC", serif',
        "bgm_mood_map": {
            "calm": "洞箫+古琴·空灵",
            "tense": "编钟+法铃·灵气涌动",
            "climax": "钟磬+雷鸣+合唱·天劫压顶",
        },
        "image_prompt": "xianxia fantasy, floating mist, spiritual glow, elegant robe, premium vertical illustrated frame",
        "video_prompt": "xianxia duel, drifting clouds, magic aura, graceful crane camera, premium short drama shot",
        "negative_prompt": "modern street, sci-fi gun, casual hoodie, watermark, childish cartoon",
    },
}

_KEYWORD_VOTES: Dict[str, Dict[str, int]] = {
    "古风": {"ancient_court": 3},
    "宫廷": {"ancient_court": 3},
    "权谋": {"ancient_court": 3},
    "宫斗": {"ancient_court": 3},
    "皇": {"ancient_court": 2},
    "王朝": {"ancient_court": 2},
    "武侠": {"ancient_court": 2, "xuanhuan_immortal": 1},
    "江湖": {"ancient_court": 2, "xuanhuan_immortal": 1},
    "民国": {"republican_noir": 3},
    "1930": {"republican_noir": 2},
    "上海": {"republican_noir": 2},
    "谍战": {"republican_noir": 3, "mystery_noir": 1},
    "老上海": {"republican_noir": 3},
    "现代": {"modern_urban": 3},
    "都市": {"modern_urban": 3},
    "校园": {"modern_urban": 3},
    "职场": {"modern_urban": 3},
    "爱情": {"modern_urban": 2},
    "青春": {"modern_urban": 2},
    "科幻": {"scifi_neon": 3},
    "赛博": {"scifi_neon": 3},
    "赛博朋克": {"scifi_neon": 4},
    "太空": {"scifi_neon": 3},
    "未来": {"scifi_neon": 2},
    "机甲": {"scifi_neon": 2},
    "AI": {"scifi_neon": 2},
    "悬疑": {"mystery_noir": 3},
    "推理": {"mystery_noir": 3},
    "恐怖": {"mystery_noir": 3},
    "惊悚": {"mystery_noir": 3},
    "侦探": {"mystery_noir": 3, "republican_noir": 1},
    "犯罪": {"mystery_noir": 2},
    "玄幻": {"xuanhuan_immortal": 3},
    "仙侠": {"xuanhuan_immortal": 3},
    "修真": {"xuanhuan_immortal": 3},
    "修仙": {"xuanhuan_immortal": 3},
    "奇幻": {"xuanhuan_immortal": 2, "scifi_neon": 1},
    "魔法": {"xuanhuan_immortal": 2},
}

_DEFAULT_THEME_KEY = "ancient_court"

_DYNAMIC_TAG_HINTS: Dict[str, List[str]] = {
    "复仇": ["复仇张力"],
    "双男主": ["双主角关系张力"],
    "双女主": ["双主角关系张力"],
    "群像": ["群像"],
    "成长": ["成长弧光"],
    "救赎": ["救赎"],
    "甜宠": ["轻甜情绪"],
    "虐恋": ["高虐情绪"],
}

_DYNAMIC_MOTIF_HINTS: Dict[str, List[str]] = {
    "复仇": ["裂痕", "冷光"],
    "雨夜": ["雨痕", "反光地面"],
    "朝堂": ["玉阶", "龙纹灯影"],
    "校园": ["走廊玻璃窗", "课桌便签"],
    "职场": ["会议室玻璃墙", "城市夜景"],
    "推理": ["案卷纸张", "线索板"],
    "太空": ["舷窗", "宇宙尘埃"],
    "仙侠": ["灵雾", "飞剑流光"],
}


def _pick_theme_key(setting: StorySetting) -> str:
    """根据 setting.genre + worldview 关键字，投票选出主题键。"""

    scores: Dict[str, float] = {k: 0.0 for k in THEME_PRESETS.keys()}
    wv = setting.worldview
    corpus_high = " ".join(setting.genre or [])
    corpus_high += " " + (wv.era or "") + " " + (wv.location or "")
    corpus_high += " " + " ".join(wv.rules or [])
    corpus_low = " ".join(
        [setting.logline or "", setting.title or "", setting.main_conflict or ""]
    )

    for kw, votes in _KEYWORD_VOTES.items():
        hi_hit = kw in corpus_high or kw.lower() in corpus_high.lower()
        lo_hit = kw in corpus_low or kw.lower() in corpus_low.lower()
        if hi_hit:
            for theme_key, weight in votes.items():
                scores[theme_key] += weight
        elif lo_hit:
            for theme_key, weight in votes.items():
                scores[theme_key] += weight * 0.5

    best_key = _DEFAULT_THEME_KEY
    best_score = -1.0
    for k, v in scores.items():
        if v > best_score:
            best_score = v
            best_key = k
    if best_score <= 0:
        return _DEFAULT_THEME_KEY
    return best_key


def _infer_visual_theme(setting: StorySetting) -> VisualTheme:
    """把主题预设物化成 VisualTheme，并叠加剧情级细节。"""

    key = _pick_theme_key(setting)
    preset = THEME_PRESETS.get(key, THEME_PRESETS[_DEFAULT_THEME_KEY])
    corpus = _story_corpus(setting)
    theme_tags = list(preset.get("theme_tags", []))
    visual_motifs = list(preset.get("visual_motifs", []))
    for kw, tags in _DYNAMIC_TAG_HINTS.items():
        if kw in corpus:
            for tag in tags:
                if tag not in theme_tags:
                    theme_tags.append(tag)
    for kw, motifs in _DYNAMIC_MOTIF_HINTS.items():
        if kw in corpus:
            for motif in motifs:
                if motif not in visual_motifs:
                    visual_motifs.append(motif)
    if setting.worldview.location and setting.worldview.location not in visual_motifs:
        visual_motifs.append(setting.worldview.location)

    return VisualTheme(
        theme_name=preset["theme_name"],
        theme_tags=theme_tags[:6],
        visual_motifs=visual_motifs[:8],
        ui_variant=preset.get("ui_variant", "default"),
        stage_effect=preset.get("stage_effect", "none"),
        palette=dict(preset["palette"]),
        scene_gradients=dict(preset["scene_gradients"]),
        particle=ParticleConfig(**preset["particle"]),
        font_family=preset["font_family"],
        bgm_mood_map=dict(preset["bgm_mood_map"]),
        image_prompt=preset.get("image_prompt", ""),
        video_prompt=preset.get("video_prompt", ""),
        negative_prompt=preset.get("negative_prompt", ""),
    )


def run_direction(
    config: PipelineConfig,
    setting: StorySetting,
    nodes: List[Node],
    router: LLMRouter,
) -> Tuple[List[Node], List[Scene], List[BGM], List[CG], List[Voiceover], VisualTheme]:
    visual_theme = _infer_visual_theme(setting)
    user_msg = (
        f"作品：《{setting.title}》\n"
        f"题材主题：{', '.join(setting.genre)}\n"
        f"世界观：{setting.worldview.era} / {setting.worldview.location}\n"
        f"主题标签：{', '.join(visual_theme.theme_tags)}\n"
        f"视觉母题：{', '.join(visual_theme.visual_motifs)}\n"
        f"用户选择的最高档位：{config.staging}\n"
        "档位定义：static=静态；semi-dynamic=局部动效；full-video=完整视频。\n\n"
        "节点列表：\n"
        + "\n".join(
            f"- {n.id} | type={n.type} | emotion={n.emotion_intensity:.2f} | content={n.content[:80]}"
            for n in nodes
        )
        + "\n\n请为每个节点填入 staging，以及 v1.2 的细粒度演出字段："
        + "scene_id/location/background/camera/bgm_id/cg_id/voiceover；"
        + "同时保留一份简短、适合低成本模型的 asset_prompt。"
    )
    resp = router.chat_json(
        role="direction",
        messages=[
            {"role": "system", "content": DIRECTION_SYSTEM},
            {"role": "user", "content": user_msg},
        ],
        schema=_StagedResponse,
    )
    for node in resp.nodes:
        node.staging = _cap_by_user_tier(node.staging, config.staging)
        _normalize_node_staging(node, setting, visual_theme)
    scenes, bgms, cgs, voiceovers = _collect_assets(resp.nodes, setting, visual_theme)
    return resp.nodes, scenes, bgms, cgs, voiceovers, visual_theme


def mock_direction(
    config: PipelineConfig, setting: StorySetting, nodes: List[Node]
) -> Tuple[List[Node], List[Scene], List[BGM], List[CG], List[Voiceover], VisualTheme]:
    """规则占位：无 API Key 时也产出完整的题材化视觉信息。"""

    visual_theme = _infer_visual_theme(setting)
    protagonist = setting.characters[0].name if setting.characters else "主角"
    scene_slots: Dict[str, str] = {}

    for idx, node in enumerate(nodes, start=1):
        node.staging = _cap_by_user_tier(_suggest_by_emotion(node.emotion_intensity), config.staging)
        slot = _scene_slot(node)
        scene_key = f"{node.act_id or 'act_default'}::{slot}"
        if scene_key not in scene_slots:
            scene_slots[scene_key] = f"s_{(node.act_id or 'act_default')}_{slot}"
        node.scene_id = scene_slots[scene_key]
        node.location = _infer_location(node, setting, slot)
        node.background = _infer_background(setting, visual_theme, slot)
        node.camera = _infer_camera(node)
        node.bgm_id = _suggest_bgm_id(node.emotion_intensity)
        node.cg_id = f"cg_{node.id}" if node.emotion_intensity >= 0.72 else None
        if node.type == "inner_monologue":
            node.voiceover = f"vo_inner_{(node.character or protagonist)}"
        elif node.type == "system":
            node.voiceover = "vo_system"
        else:
            node.voiceover = None
        if not node.character and node.type in ("dialogue", "inner_monologue"):
            node.character = protagonist
        node.asset_prompt = _build_asset_prompt(node, setting, visual_theme, protagonist, idx)

    scenes, bgms, cgs, voiceovers = _collect_assets(nodes, setting, visual_theme)
    return nodes, scenes, bgms, cgs, voiceovers, visual_theme


def _normalize_node_staging(node: Node, setting: StorySetting, theme: VisualTheme) -> None:
    """对 LLM 输出做收口，保证缺失字段也能落地。"""

    protagonist = setting.characters[0].name if setting.characters else "主角"
    if not node.scene_id:
        node.scene_id = f"s_{node.act_id or 'act_default'}_{_scene_slot(node)}"
    if not node.location:
        node.location = _infer_location(node, setting, _scene_slot(node))
    if not node.background:
        node.background = _infer_background(setting, theme, _scene_slot(node))
    if not node.camera:
        node.camera = _infer_camera(node)
    if not node.bgm_id:
        node.bgm_id = _suggest_bgm_id(node.emotion_intensity)
    if node.type == "inner_monologue" and not node.voiceover:
        node.voiceover = f"vo_inner_{(node.character or protagonist)}"
    if node.type == "system" and not node.voiceover:
        node.voiceover = "vo_system"
    if node.emotion_intensity >= 0.72 and not node.cg_id:
        node.cg_id = f"cg_{node.id}"
    if not node.asset_prompt:
        node.asset_prompt = _build_asset_prompt(node, setting, theme, protagonist, 0)


def _collect_assets(
    nodes: List[Node], setting: StorySetting, theme: VisualTheme
) -> Tuple[List[Scene], List[BGM], List[CG], List[Voiceover]]:
    scene_dict: Dict[str, Scene] = {}
    bgm_dict: Dict[str, BGM] = {}
    cg_dict: Dict[str, CG] = {}
    vo_dict: Dict[str, Voiceover] = {}
    for n in nodes:
        if n.scene_id and n.scene_id not in scene_dict:
            scene_dict[n.scene_id] = Scene(
                id=n.scene_id,
                location=n.location or setting.worldview.location,
                background=n.background,
                description=f"{theme.theme_name} 场景：{n.location or setting.worldview.location}",
                default_bgm_id=n.bgm_id,
            )
        if n.bgm_id and n.bgm_id not in bgm_dict:
            mood = n.bgm_id.replace("bgm_", "")
            bgm_dict[n.bgm_id] = BGM(
                id=n.bgm_id,
                name={
                    "bgm_calm": "舒缓·日常",
                    "bgm_tense": "紧张·推进",
                    "bgm_climax": "激烈·高潮",
                }.get(n.bgm_id, n.bgm_id),
                description=theme.bgm_mood_map.get(mood, "按情绪强度自动分档"),
            )
        if n.cg_id and n.cg_id not in cg_dict:
            cg_dict[n.cg_id] = CG(
                id=n.cg_id,
                description=f"{theme.theme_name} 高情绪 CG：{(n.content or '')[:24]}",
                scene_id=n.scene_id,
            )
        if n.voiceover and n.voiceover not in vo_dict:
            vo_dict[n.voiceover] = Voiceover(
                id=n.voiceover,
                speaker=n.character or "系统",
                text=n.content if n.type in ("inner_monologue", "system") else None,
            )
    return (
        list(scene_dict.values()),
        list(bgm_dict.values()),
        list(cg_dict.values()),
        list(vo_dict.values()),
    )


def _story_corpus(setting: StorySetting) -> str:
    wv = setting.worldview
    return " ".join(
        [
            setting.title or "",
            setting.logline or "",
            setting.main_conflict or "",
            " ".join(setting.genre or []),
            wv.era or "",
            wv.location or "",
            " ".join(wv.rules or []),
        ]
    )


def _scene_slot(node: Node) -> str:
    content = node.content or ""
    if any(kw in content for kw in ["宫", "殿", "朝", "王座", "百官"]):
        return "ceremony"
    if any(kw in content for kw in ["房", "室", "书房", "寝宫", "病房", "宿舍", "办公室"]):
        return "chamber"
    if any(kw in content for kw in ["夜", "雨", "巷", "街", "天台", "桥", "车站"]):
        return "night"
    if any(kw in content for kw in ["战", "逃", "追", "爆炸", "法阵", "失控"]):
        return "climax"
    if node.type == "ending":
        return "ending"
    return "daily"


def _infer_location(node: Node, setting: StorySetting, slot: str) -> str:
    base = setting.worldview.location or "未知地点"
    suffix_map = {
        "ceremony": "核心权力场",
        "chamber": "私密空间",
        "night": "夜色场景",
        "climax": "高压冲突区",
        "ending": "尾声场域",
        "daily": "日常场景",
    }
    return f"{base}·{suffix_map.get(slot, '场景')}"


def _infer_background(setting: StorySetting, theme: VisualTheme, slot: str) -> str:
    motifs = " / ".join(theme.visual_motifs[:3])
    era = setting.worldview.era or "未定时代"
    loc = setting.worldview.location or "未定地点"
    slot_cn = {
        "ceremony": "主场景",
        "chamber": "室内情绪场",
        "night": "夜景",
        "climax": "高潮场",
        "ending": "尾声场",
        "daily": "日常场",
    }.get(slot, "场景")
    return f"{era}·{loc}·{slot_cn}，视觉母题：{motifs}"


def _infer_camera(node: Node) -> str:
    e = node.emotion_intensity or 0.5
    if node.type == "ending":
        return "中远景定格"
    if node.type == "inner_monologue":
        return "近景缓推"
    if e >= 0.82:
        return "特写+轻微晃动"
    if e >= 0.58:
        return "中近景"
    return "远景建立镜头"


def _build_asset_prompt(
    node: Node,
    setting: StorySetting,
    theme: VisualTheme,
    protagonist: str,
    idx: int,
) -> str:
    subject = node.character or protagonist
    anchor = theme.video_prompt if node.staging == "full-video" else theme.image_prompt
    mood = "激烈" if node.emotion_intensity >= 0.72 else "紧张" if node.emotion_intensity >= 0.45 else "克制"
    scene = node.location or (setting.worldview.location or "场景")
    camera = node.camera or _infer_camera(node)
    motifs = "、".join(theme.visual_motifs[:2])
    action = (node.content or "")[:32]
    parts = [
        subject,
        scene,
        camera,
        f"{mood}氛围",
        f"母题:{motifs}" if motifs else "",
        action,
        anchor,
    ]
    prompt = "；".join(p for p in parts if p)
    if theme.negative_prompt:
        prompt += f"；避免:{theme.negative_prompt}"
    return prompt[:280]


def dispatch_asset_generation(nodes: List[Node]) -> None:
    """预留：把 semi-dynamic / full-video 节点的 asset_prompt 提交到素材生成流水线。"""
    # TODO: connect to actual asset generation providers
    pass
