"""P1：导出可玩 H5 互动游戏 zip 包。

产出的 zip 结构（根目录含 ``index.html``，符合抖音互动空间上传要求）::

    game.zip
    ├── index.html      # 入口，双击即可本地游玩
    ├── player.css      # 播放器样式
    ├── player.js       # 播放器引擎
    ├── game-data.js    # window.__GAME__ = <GameOutput JSON>
    └── assets/         # 图片 / 视频素材（若生成过）
        ├── n_xxx.png
        └── ...

约束：
    - 根目录必须有 ``index.html``；
    - 整包 ≤ 8MB（抖音互动空间限制），超出时在返回结果里 ``oversize=True`` 告警。
"""

from __future__ import annotations

import json
import logging
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

from .models import GameOutput
from .player import player_dir

logger = logging.getLogger(__name__)

MAX_ZIP_BYTES = 8 * 1024 * 1024  # 8MB


@dataclass
class ExportResult:
    zip_path: Path
    size_bytes: int
    oversize: bool
    file_count: int
    asset_count: int
    has_index: bool

    def as_dict(self) -> Dict:
        return {
            "zip_path": str(self.zip_path),
            "size_bytes": self.size_bytes,
            "size_mb": round(self.size_bytes / 1024 / 1024, 3),
            "oversize": self.oversize,
            "max_mb": 8,
            "file_count": self.file_count,
            "asset_count": self.asset_count,
            "has_index": self.has_index,
        }


def export_game(
    game: GameOutput,
    out_zip: Path,
    assets_dir: Optional[Path] = None,
) -> ExportResult:
    """把一个 GameOutput 打包成可本地游玩、可上传抖音互动空间的 zip。

    :param game: 结构化产物
    :param out_zip: 输出 zip 路径
    :param assets_dir: 素材目录（含 media_url 引用的 png/mp4）；None 或不存在则不打素材
    """
    out_zip = Path(out_zip)
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    pdir = player_dir()

    with tempfile.TemporaryDirectory() as tmp:
        build = Path(tmp)

        # 1. index.html（替换标题占位）
        template = (pdir / "index_template.html").read_text(encoding="utf-8")
        index_html = template.replace("__TITLE__", _esc(game.title or "互动漫剧"))
        (build / "index.html").write_text(index_html, encoding="utf-8")

        # 2. 播放器引擎
        shutil.copy2(pdir / "player.css", build / "player.css")
        shutil.copy2(pdir / "player.js", build / "player.js")

        # 3. game-data.js（内联游戏数据，规避 file:// 的 fetch 限制）
        # 注：GameOutput 是 Pydantic 模型，model_dump_json() 会把整棵树完整序列化，
        # 包括 v1.2 追加的 `visual_theme`（palette / scene_gradients / particle /
        # font_family / bgm_mood_map）。播放器在 mount 时会读取 window.__GAME__
        # .visual_theme，把 palette 注入 CSS 变量、scene_gradients 用作占位底图、
        # 按 particle.type 启动粒子层——所以 exporter 侧无需为主题额外做任何事。
        game_json = game.model_dump_json()
        (build / "game-data.js").write_text(
            "window.__GAME__ = " + game_json + ";\n", encoding="utf-8"
        )

        # 4. 素材：仅拷贝被 media_url 引用到的文件
        asset_count = 0
        referenced = _referenced_assets(game)
        if assets_dir and Path(assets_dir).exists() and referenced:
            dst = build / "assets"
            dst.mkdir(parents=True, exist_ok=True)
            for rel in referenced:
                # rel 形如 "assets/n_xxx.png"
                name = Path(rel).name
                src = Path(assets_dir) / name
                if src.exists():
                    shutil.copy2(src, dst / name)
                    asset_count += 1

        # 5. 打 zip（根目录直接是这些文件）
        file_count = 0
        if out_zip.exists():
            out_zip.unlink()
        with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for path in sorted(build.rglob("*")):
                if path.is_file():
                    zf.write(path, path.relative_to(build).as_posix())
                    file_count += 1

    size = out_zip.stat().st_size
    result = ExportResult(
        zip_path=out_zip,
        size_bytes=size,
        oversize=size > MAX_ZIP_BYTES,
        file_count=file_count,
        asset_count=asset_count,
        has_index=True,
    )
    if result.oversize:
        logger.warning(
            "导出包 %.2fMB 超过抖音互动空间 8MB 限制，建议调低 video_ratio 或素材分辨率",
            size / 1024 / 1024,
        )
    return result


def _referenced_assets(game: GameOutput) -> List[str]:
    refs: List[str] = []
    seen = set()
    for n in game.story_tree.nodes:
        if n.media_url and n.media_url not in seen:
            seen.add(n.media_url)
            refs.append(n.media_url)
    return refs


def _esc(s: str) -> str:
    return s.replace("<", "&lt;").replace(">", "&gt;")
