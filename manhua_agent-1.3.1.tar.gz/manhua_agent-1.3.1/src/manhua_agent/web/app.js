/* ============================================================
 * 互动漫剧生成器 · 包内前端逻辑（可随 whl 一起安装）
 * ============================================================ */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  const state = {
    mode: "keywords",
    jobId: null,
    poll: null,
    skeleton: null,
    game: null,
    config: null,
    player: null,
    lastStatus: null,
  };

  async function api(path, opts) {
    const res = await fetch(path, opts);
    if (!res.ok) {
      let detail = res.statusText;
      try { detail = (await res.json()).detail || detail; } catch {}
      throw new Error(detail);
    }
    return res.json();
  }

  function toast(msg, isErr) {
    const el = $("#gToast");
    el.textContent = msg;
    el.className = "toast-global show" + (isErr ? " err" : "");
    setTimeout(() => { el.className = "toast-global"; }, 2600);
  }

  function gotoStep(n) {
    for (let i = 1; i <= 5; i++) {
      const p = $("#panel" + i);
      if (p) p.style.display = i === n ? "" : "none";
    }
    $$("#stepbar .step").forEach((el) => {
      const s = Number(el.dataset.step || 0);
      el.classList.toggle("active", s === n);
      el.classList.toggle("done", s < n);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function statusLabel(status) {
    const map = {
      created: "任务已创建",
      running_plan: "正在解析与规划",
      awaiting_confirm: "等待人工确认",
      running_after: "正在继续生成",
      generating_characters: "正在生成角色素材",
      generating_assets: "正在生成场景素材",
      finished: "生成完成",
      error: "任务失败",
    };
    return map[status] || status || "未知状态";
  }

  function updateSliders() {
    $("#branchVal").textContent = $("#branchCount").value;
    $("#nodesVal").textContent = $("#maxNodes").value;
    $("#ratioVal").textContent = Number($("#videoRatio").value).toFixed(2);
  }

  function esc(s) {
    return String(s === null || s === undefined ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  async function loadConfig() {
    try {
      const cfg = await api("/api/config");
      state.config = cfg;
      $("#videoRatio").value = cfg.video_ratio;
      $("#dryRun").checked = !!cfg.auto_dry_run;
      updateSliders();
      $("#envBadges").innerHTML = [
        ["LLM", cfg.llm_ready],
        ["图片API", cfg.image_api_ready],
        ["视频API", cfg.video_api_ready],
        ["Demo", cfg.demo_mode_available],
      ].map(([name, on]) => `<span class="badge ${on ? "on" : "off"}">${on ? "●" : "○"} ${name}</span>`).join("");
    } catch {
      $("#envBadges").innerHTML = '<span class="badge off">配置读取失败</span>';
    }
  }

  function setupModeToggle() {
    $$("#modeSeg .seg").forEach((btn) => {
      btn.onclick = () => {
        $$("#modeSeg .seg").forEach((x) => x.classList.remove("active"));
        btn.classList.add("active");
        state.mode = btn.dataset.mode;
        $("#kwBlock").style.display = state.mode === "keywords" ? "" : "none";
        $("#novelBlock").style.display = state.mode === "novel" ? "" : "none";
      };
    });
  }

  function setupFileInput() {
    $("#novelFile").addEventListener("change", async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      $("#novelText").value = await file.text();
    });
  }

  function renderSteps(steps) {
    const list = $("#agentList");
    list.innerHTML = (steps || []).map((s) => `
      <li class="agent agent-${esc(s.status)}">
        <div class="agent-title">${esc(s.label || s.key)}</div>
        <div class="agent-desc">${esc(s.desc || "")}</div>
        <div class="agent-meta">${esc(s.status)}${s.message ? ` · ${esc(s.message)}` : ""}</div>
      </li>
    `).join("");
  }

  function renderAssetProgress(prog, label) {
    if (!prog || !prog.total) {
      $("#assetBar").style.display = "none";
      return;
    }
    $("#assetBar").style.display = "";
    const pct = Math.max(0, Math.min(100, Math.round((prog.done / prog.total) * 100)));
    $("#assetFill").style.width = pct + "%";
    $("#assetMsg").textContent = `${label}：${prog.done}/${prog.total} ${prog.message || ""}`;
  }

  function fillBranchEditor(skeleton) {
    $("#varsView").innerHTML = Object.entries(skeleton.variables || {}).map(([k, v]) =>
      `<span class="chip">${esc(k)}: <b>${esc(v)}</b></span>`
    ).join("");

    const html = (skeleton.branches || []).map((b, idx) => `
      <div class="branch-card" data-index="${idx}">
        <div class="field"><label>分支标题</label><input data-k="label" value="${esc(b.label)}" /></div>
        <div class="field"><label>冲突源</label><input data-k="conflict_source" value="${esc(b.conflict_source)}" /></div>
        <div class="field"><label>结局走向</label><input data-k="ending_direction" value="${esc(b.ending_direction)}" /></div>
        <div class="field"><label>关键道具（逗号分隔）</label><input data-k="key_props" value="${esc((b.key_props || []).join(", "))}" /></div>
        <div class="field"><label>节拍大纲（每行一个）</label><textarea data-k="beats" rows="5">${esc((b.beats || []).join("\n"))}</textarea></div>
      </div>
    `).join("");
    $("#branchEditor").innerHTML = html;
  }

  function collectSkeletonEdits() {
    const skeleton = JSON.parse(JSON.stringify(state.skeleton));
    $$("#branchEditor .branch-card").forEach((card) => {
      const idx = Number(card.dataset.index);
      const branch = skeleton.branches[idx];
      branch.label = card.querySelector('[data-k="label"]').value.trim();
      branch.conflict_source = card.querySelector('[data-k="conflict_source"]').value.trim();
      branch.ending_direction = card.querySelector('[data-k="ending_direction"]').value.trim();
      branch.key_props = card.querySelector('[data-k="key_props"]').value.split(",").map((x) => x.trim()).filter(Boolean);
      branch.beats = card.querySelector('[data-k="beats"]').value.split("\n").map((x) => x.trim()).filter(Boolean);
    });
    return skeleton;
  }

  async function loadSkeleton() {
    if (!state.jobId) return;
    state.skeleton = await api(`/api/jobs/${state.jobId}/skeleton`);
    fillBranchEditor(state.skeleton);
  }

  async function loadGame() {
    if (!state.jobId) return;
    state.game = await api(`/api/jobs/${state.jobId}/game`);
    $("#gameStats").innerHTML = `
      <h3>${esc(state.game.title || "未命名作品")}</h3>
      <p>${esc(state.game.logline || "")}</p>
      <div class="chips">
        ${(state.game.genre || []).map((g) => `<span class="chip">${esc(g)}</span>`).join("")}
      </div>
    `;
    const theme = state.game.visual_theme || {};
    $("#assetStats").innerHTML = `
      <h3>主题演出</h3>
      <p>theme：${esc(theme.theme_name || "default")}</p>
      <p>ui：${esc(theme.ui_variant || "default")} / effect：${esc(theme.stage_effect || "none")}</p>
      <div class="chips">${(theme.theme_tags || []).map((t) => `<span class="chip">${esc(t)}</span>`).join("")}</div>
    `;

    const host = $("#playerHost");
    host.innerHTML = "";
    if (state.player && state.player.destroy) state.player.destroy();
    state.player = window.ManhuaPlayer.mount(host, state.game, { assetBase: `/api/jobs/${state.jobId}/` });
  }

  async function pollStatus() {
    if (!state.jobId) return;
    let s;
    try {
      s = await api(`/api/jobs/${state.jobId}/status`);
    } catch {
      return;
    }

    renderSteps(s.steps);
    $("#runStatusLine").textContent = statusLabel(s.status);
    renderAssetProgress(s.char_art_progress, "角色素材");
    if (s.status === "generating_assets") {
      renderAssetProgress(s.asset_progress, "场景素材");
    }

    if (s.status !== state.lastStatus) {
      state.lastStatus = s.status;
      if (s.status === "awaiting_confirm") {
        clearInterval(state.poll);
        state.poll = null;
        await loadSkeleton();
        gotoStep(4);
      } else if (s.status === "finished") {
        clearInterval(state.poll);
        state.poll = null;
        await loadGame();
        gotoStep(5);
      } else if (s.status === "error") {
        clearInterval(state.poll);
        state.poll = null;
        toast(s.error || "任务失败", true);
      }
    }
  }

  function startPolling() {
    if (state.poll) clearInterval(state.poll);
    state.poll = setInterval(pollStatus, 1000);
    pollStatus();
  }

  async function createJob() {
    const body = {
      mode: state.mode,
      keywords: state.mode === "keywords" ? $("#keywords").value.split(",").map((x) => x.trim()).filter(Boolean) : [],
      novel_text: state.mode === "novel" ? $("#novelText").value : null,
      theme: $("#theme").value.trim() || null,
      title: $("#title").value.trim() || null,
      branch_count: Number($("#branchCount").value),
      staging: $("#staging").value,
      max_nodes_per_branch: Number($("#maxNodes").value),
      video_ratio: Number($("#videoRatio").value),
      dry_run: $("#dryRun").checked,
    };
    const r = await api("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    state.jobId = r.job_id;
    if (r.demo_mode_forced) toast("当前未配置 LLM API Key，已自动切换到内置演示模式");
    gotoStep(3);
    startPolling();
  }

  async function confirmContinue() {
    const skeleton = collectSkeletonEdits();
    await api(`/api/jobs/${state.jobId}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ skeleton }),
    });
    gotoStep(3);
    startPolling();
  }

  async function doExport() {
    const r = await api(`/api/jobs/${state.jobId}/export`, { method: "POST" });
    $("#exportInfo").innerHTML = `
      <p>导出成功：${r.file_count || 0} 个文件，大小 ${(r.zip_size_mb || 0).toFixed ? r.zip_size_mb.toFixed(2) : r.zip_size_mb} MB</p>
      ${r.oversize ? '<p class="warn">⚠ 超过 8MB，请减少素材数量</p>' : ""}
    `;
    const dl = $("#downloadBtn");
    dl.style.display = "";
    dl.href = `/api/jobs/${state.jobId}/download`;
  }

  function bindEvents() {
    $("#branchCount").oninput = updateSliders;
    $("#maxNodes").oninput = updateSliders;
    $("#videoRatio").oninput = updateSliders;
    $("#toStep2").onclick = () => gotoStep(2);
    $("#backTo1").onclick = () => gotoStep(1);
    $("#startRun").onclick = () => createJob().catch((e) => toast(e.message || String(e), true));
    $("#reloadSkeleton").onclick = () => loadSkeleton().catch((e) => toast(e.message || String(e), true));
    $("#confirmContinue").onclick = () => confirmContinue().catch((e) => toast(e.message || String(e), true));
    $("#exportBtn").onclick = () => doExport().catch((e) => toast(e.message || String(e), true));
    $("#restartAll").onclick = () => location.reload();
  }

  setupModeToggle();
  setupFileInput();
  bindEvents();
  loadConfig();
  updateSliders();
  gotoStep(1);
})();
