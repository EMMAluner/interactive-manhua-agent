"""P1 播放器子包：H5 引擎静态资源（预览与导出共用）。

包含（package-data）:
    - player.css / player.js       : 播放器引擎
    - index_template.html          : 导出包的入口模板

通过 :func:`player_dir` 拿到资源目录，供 FastAPI 静态挂载与导出打包使用。
"""

from __future__ import annotations

from pathlib import Path


def player_dir() -> Path:
    """返回本子包目录（含 player.css / player.js / index_template.html）。"""
    return Path(__file__).resolve().parent
