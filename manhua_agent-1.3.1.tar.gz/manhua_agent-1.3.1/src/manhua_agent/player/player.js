/* ==========================================================================
 * 互动漫剧 H5 播放器引擎（预览与导出共用）
 *
 * 用法：
 *   ManhuaPlayer.mount(container, game, { assetBase: '' });
 *
 * - game：GameOutput（schema 1.2）对象
 * - assetBase：素材相对路径前缀。导出包内为 ''（同目录），预览时为
 *   '/api/jobs/<id>/'（后端提供素材静态服务）。节点 media_url 形如
 *   'assets/n_xxx.png'，最终 src = assetBase + media_url。
 *
 * 方案B：视觉主题动态化
 * ---------------------------------------------------------------------
 * 播放器会读取 game.visual_theme（VisualTheme），把 palette 中的每个 key
 * 映射为 --mh-<key-with-dashes> 的 CSS 变量并 setProperty 到播放器根节点，
 * 让 player.css 里预置的暗紫默认皮肤被覆盖成剧本对应的风格。
 * 场景占位底图从 theme.scene_gradients 读取（按情绪/结局分桶）。
 * 粒子层根据 theme.particle.type 在 stage 顶部渲染 canvas 动效
 *   （sakura / snow / leaves / ember / starfield / dust / none）。
 * 字体族由 theme.font_family 覆盖播放器根节点的 font-family。
 * ========================================================================== */
(function (global) {
  "use strict";

  // ------------------------- 条件 AST 求值 ------------------------- //
  function evalCond(cond, state) {
    if (!cond) return true;
    switch (cond.type) {
      case "var_cmp": {
        const v = state.variables[cond.var] || 0;
        switch (cond.op) {
          case ">": return v > cond.value;
          case ">=": return v >= cond.value;
          case "<": return v < cond.value;
          case "<=": return v <= cond.value;
          case "==": return v === cond.value;
          case "!=": return v !== cond.value;
          default: return true;
        }
      }
      case "has_item":
        return (state.inventory[cond.item_id] || 0) >= (cond.min_count || 1);
      case "choice_taken":
        return state.taken.has(cond.node_id + "#" + cond.choice_index);
      case "and":
        return (cond.conditions || []).every((c) => evalCond(c, state));
      case "or":
        return (cond.conditions || []).some((c) => evalCond(c, state));
      case "not":
        return !evalCond(cond.condition, state);
      default:
        return true;
    }
  }

  function renderCond(cond) {
    if (!cond) return "";
    if (cond.expression) return cond.expression;
    switch (cond.type) {
      case "var_cmp": return `${cond.var}${cond.op}${cond.value}`;
      case "has_item": return `需要道具`;
      case "and": return (cond.conditions || []).map(renderCond).join(" 且 ");
      case "or": return (cond.conditions || []).map(renderCond).join(" 或 ");
      case "not": return "非(" + renderCond(cond.condition) + ")";
      default: return "";
    }
  }

  // ------------------------- 主题工具 ------------------------- //
  // palette key -> CSS variable name。规则：
  //   'bg'       -> '--mh-bg'
  //   'panel'    -> '--mh-panel'
  //   'panel_border' -> '--mh-panel-border'
  //   'ink_dim'  -> '--mh-ink-dim'
  // 播放器 CSS 里也是这种命名（详见 player.css）。
  function paletteKeyToVar(key) {
    return "--mh-" + String(key).replace(/_/g, "-");
  }

  // 情绪强度 → scene_gradients 桶键
  function bucketFromEmotion(node) {
    if (!node) return "default";
    if (node.type === "ending") {
      // 结局节点如果有 branch_id，按颜色分桶
      const bid = (node.branch_id || "").toLowerCase();
      if (/(love|true|good|hope|light)/.test(bid)) return "ending_true";
      if (/(bad|dark|die|revenge|blood)/.test(bid)) return "ending_bad";
      // 默认按情绪判断
      return node.emotion_intensity > 0.5 ? "climax" : "ending_true";
    }
    const e = node.emotion_intensity || 0.5;
    if (e < 0.4) return "daily";
    if (e < 0.7) return "tense";
    return "climax";
  }

  // ------------------------- 粒子引擎 ------------------------- //
  // 单个粒子的通用结构：{x, y, size, vx, vy, rot, vr, alpha, phase, hue}
  //
  // 各粒子类型的绘制/更新策略：
  //   sakura   → 圆瓣飘落 + 缓慢自转 + 横向漂移
  //   snow     → 小白圆点竖向下落 + 微弱横向漂移
  //   leaves   → 长椭圆飘落 + 强自转
  //   ember    → 火星从底部升起 + 上升过程中变暗消散
  //   starfield→ 静态星点位置 + 亮度周期呼吸
  //   dust     → 缓慢漂浮的浮尘光粒 + 上下轻微摆动
  function ParticleLayer(canvas, cfg) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.cfg = Object.assign({
      type: "none",
      density: 0.5,
      color: null,
      size_min: 1.0,
      size_max: 3.0,
      speed: 1.0,
      opacity: 0.75,
    }, cfg || {});
    this.particles = [];
    this.running = false;
    this._resize = this._resize.bind(this);
    this._tick = this._tick.bind(this);
  }

  ParticleLayer.prototype.start = function () {
    if (this.cfg.type === "none") return;
    this._resize();
    if (typeof ResizeObserver !== "undefined") {
      this._ro = new ResizeObserver(this._resize);
      this._ro.observe(this.canvas);
    } else {
      window.addEventListener("resize", this._resize);
    }
    this._spawn();
    this.running = true;
    this._raf = requestAnimationFrame(this._tick);
  };

  ParticleLayer.prototype.stop = function () {
    this.running = false;
    if (this._raf) cancelAnimationFrame(this._raf);
    if (this._ro) this._ro.disconnect();
    window.removeEventListener("resize", this._resize);
  };

  ParticleLayer.prototype._resize = function () {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    // 使用 CSS 尺寸为 rect，画布内部按 DPR 放大
    this.canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    this.canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    this.dpr = dpr;
    this.w = rect.width;
    this.h = rect.height;
  };

  ParticleLayer.prototype._spawn = function () {
    // 密度 → 数量：以 400x700 为参考，最多 120 个粒子
    const area = Math.max(1, (this.w || 400) * (this.h || 700));
    const base = Math.round((area / (400 * 700)) * 120);
    const n = Math.max(6, Math.round(base * (this.cfg.density || 0.5)));
    this.particles = [];
    for (let i = 0; i < n; i++) this.particles.push(this._createOne(true));
  };

  ParticleLayer.prototype._createOne = function (initial) {
    const w = this.w || 400, h = this.h || 700;
    const sz = this._rand(this.cfg.size_min || 1, this.cfg.size_max || 3);
    const type = this.cfg.type;
    let x = this._rand(0, w);
    let y = this._rand(0, h);
    let vx = 0, vy = 0, phase = Math.random() * Math.PI * 2;
    const speed = this.cfg.speed || 1.0;
    if (type === "sakura" || type === "leaves") {
      if (!initial) y = -20;
      vy = this._rand(0.4, 1.1) * speed;
      vx = this._rand(-0.4, 0.4) * speed;
    } else if (type === "snow") {
      if (!initial) y = -10;
      vy = this._rand(0.6, 1.4) * speed;
      vx = this._rand(-0.2, 0.2) * speed;
    } else if (type === "ember") {
      if (!initial) y = h + 10;
      vy = -this._rand(0.5, 1.2) * speed;
      vx = this._rand(-0.3, 0.3) * speed;
    } else if (type === "dust") {
      vx = this._rand(-0.15, 0.15) * speed;
      vy = this._rand(-0.15, 0.15) * speed;
    } else if (type === "starfield") {
      vx = 0; vy = 0;
    }
    return {
      x: x, y: y,
      size: sz,
      vx: vx, vy: vy,
      rot: this._rand(0, Math.PI * 2),
      vr: this._rand(-0.03, 0.03),
      alpha: this._rand(0.5, 1.0) * (this.cfg.opacity || 0.75),
      phase: phase,
      born: performance.now(),
    };
  };

  ParticleLayer.prototype._rand = function (a, b) {
    return a + Math.random() * (b - a);
  };

  ParticleLayer.prototype._defaultColor = function () {
    if (this.cfg.color) return this.cfg.color;
    switch (this.cfg.type) {
      case "sakura": return "#f6c9d4";
      case "snow":   return "#ffffff";
      case "leaves": return "#c88a3a";
      case "ember":  return "#ffb060";
      case "starfield": return "#e8f4ff";
      case "dust":   return "#e8d8b8";
      default:       return "#ffffff";
    }
  };

  ParticleLayer.prototype._tick = function () {
    if (!this.running) return;
    const ctx = this.ctx, dpr = this.dpr, w = this.w, h = this.h;
    const type = this.cfg.type;
    const color = this._defaultColor();
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    ctx.save();
    ctx.scale(dpr, dpr);
    const now = performance.now();
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      // 更新
      if (type === "sakura" || type === "leaves") {
        p.x += p.vx + Math.sin((now / 900) + p.phase) * 0.35;
        p.y += p.vy;
        p.rot += p.vr;
        if (p.y > h + 20) { this.particles[i] = this._createOne(false); continue; }
      } else if (type === "snow") {
        p.x += p.vx + Math.sin((now / 1200) + p.phase) * 0.2;
        p.y += p.vy;
        if (p.y > h + 10) { this.particles[i] = this._createOne(false); continue; }
      } else if (type === "ember") {
        p.x += p.vx + Math.sin((now / 700) + p.phase) * 0.4;
        p.y += p.vy;
        // 上升过程逐渐变暗
        const life = (now - p.born) / 3500;
        p.alpha = Math.max(0, (this.cfg.opacity || 0.75) * (1 - life));
        if (p.y < -20 || p.alpha <= 0) { this.particles[i] = this._createOne(false); continue; }
      } else if (type === "dust") {
        p.x += p.vx + Math.sin((now / 1600) + p.phase) * 0.05;
        p.y += p.vy + Math.cos((now / 1800) + p.phase) * 0.04;
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;
        if (p.y < -10) p.y = h + 10;
        if (p.y > h + 10) p.y = -10;
      } else if (type === "starfield") {
        // 星点：静态位置 + 呼吸亮度
        const twinkle = 0.5 + 0.5 * Math.sin((now / 900) + p.phase);
        p.alpha = (this.cfg.opacity || 0.75) * (0.35 + 0.65 * twinkle);
      }
      // 绘制
      ctx.globalAlpha = Math.max(0, Math.min(1, p.alpha));
      if (type === "starfield") {
        // 中心亮点 + 十字光晕
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        if (p.size > 1.4) {
          ctx.strokeStyle = color;
          ctx.lineWidth = 0.4;
          ctx.beginPath();
          ctx.moveTo(p.x - p.size * 2, p.y);
          ctx.lineTo(p.x + p.size * 2, p.y);
          ctx.moveTo(p.x, p.y - p.size * 2);
          ctx.lineTo(p.x, p.y + p.size * 2);
          ctx.stroke();
        }
      } else if (type === "sakura") {
        // 花瓣：椭圆 + 旋转
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size * 0.55, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (type === "leaves") {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size * 1.2, p.size * 0.45, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (type === "ember") {
        // 火星：径向渐变小圆
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 2.2);
        g.addColorStop(0, color);
        g.addColorStop(1, "rgba(255,120,40,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 2.2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // snow / dust：普通圆点
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
    this._raf = requestAnimationFrame(this._tick);
  };

  // ------------------------- 播放器类 ------------------------- //
  function Player(container, game, opts) {
    this.el = container;
    this.game = game;
    this.opts = opts || {};
    this.assetBase = this.opts.assetBase || "";
    this.theme = game.visual_theme || null;
    this.nodeMap = {};
    (game.story_tree.nodes || []).forEach((n) => (this.nodeMap[n.id] = n));
    this.nodeOrder = (game.story_tree.nodes || []).map((n) => n.id);
    this.itemMap = {};
    ((game.assets && game.assets.items) || []).forEach((it) => (this.itemMap[it.id] = it));
    this.endings = game.story_tree.endings || [];
    this.reset();
  }

  Player.prototype.reset = function () {
    this.state = {
      variables: Object.assign({}, this.game.variables || {}),
      inventory: {},
      taken: new Set(),
    };
    // 先关掉旧粒子层再重建 shell
    if (this._particles) { this._particles.stop(); this._particles = null; }
    this.el.classList.add("mh-root");
    this.el.innerHTML = "";
    this._applyTheme();
    this._buildShell();
    this._mountParticles();
    this.show(this.game.story_tree.start_node);
  };

  /**
   * 把 visual_theme.palette 注入到播放器根节点，把 font_family 覆盖到根节点。
   *
   * 注意：使用 setProperty("--mh-xxx", value) 而不是全局 :root，避免多个播放器
   * 挂在同一页面时相互污染。
   */
  Player.prototype._applyTheme = function () {
    const theme = this.theme;
    if (!theme) {
      this.el.setAttribute("data-mh-theme", "default");
      this.el.setAttribute("data-mh-ui", "default");
      this.el.setAttribute("data-mh-effect", "none");
      return;
    }
    const palette = theme.palette || {};
    Object.keys(palette).forEach((k) => {
      const varName = paletteKeyToVar(k);
      this.el.style.setProperty(varName, palette[k]);
    });
    if (theme.font_family) {
      this.el.style.setProperty("--mh-font", theme.font_family);
    }
    this.el.setAttribute("data-mh-theme", theme.theme_name || "default");
    this.el.setAttribute("data-mh-ui", theme.ui_variant || "default");
    this.el.setAttribute("data-mh-effect", theme.stage_effect || "none");
  };

  Player.prototype._buildShell = function () {
    const g = this.game;
    const theme = this.theme || {};
    const themeTags = ((theme.theme_tags || []).slice(0, 3))
      .map((t) => `<span class="mh-theme-tag">${esc(t)}</span>`)
      .join("");
    this.el.innerHTML = `
      <div class="mh-stage" data-mh="stage">
        <div class="mh-stage-overlay" data-mh="overlay"></div>
        <canvas class="mh-particles" data-mh="particles"></canvas>
      </div>
      <div class="mh-topbar">
        <div class="mh-title-wrap">
          <span class="mh-title">${esc(g.title || "互动漫剧")}</span>
          <div class="mh-theme-tags">${themeTags}</div>
        </div>
        <button class="mh-restart" data-mh="restart">↺ 重玩</button>
      </div>
      <div class="mh-hud" data-mh="hud"></div>
      <div class="mh-toast" data-mh="toast"></div>
      <div class="mh-bottom" data-mh="bottom"></div>
    `;
    const self = this;
    this.el.querySelector('[data-mh="restart"]').onclick = function () {
      self.reset();
    };
    this.$stage = this.el.querySelector('[data-mh="stage"]');
    this.$hud = this.el.querySelector('[data-mh="hud"]');
    this.$bottom = this.el.querySelector('[data-mh="bottom"]');
    this.$toast = this.el.querySelector('[data-mh="toast"]');
    this.$particles = this.el.querySelector('[data-mh="particles"]');
  };

  Player.prototype._mountParticles = function () {
    if (!this.$particles) return;
    const cfg = (this.theme && this.theme.particle) ? this.theme.particle : { type: "none" };
    if (!cfg || cfg.type === "none") return;
    this._particles = new ParticleLayer(this.$particles, cfg);
    this._particles.start();
  };

  Player.prototype.toast = function (msg) {
    if (!msg) return;
    this.$toast.textContent = msg;
    this.$toast.classList.add("mh-show");
    clearTimeout(this._toastT);
    const self = this;
    this._toastT = setTimeout(() => self.$toast.classList.remove("mh-show"), 1400);
  };

  Player.prototype._applyItems = function (gain, consume, effects) {
    const inv = this.state.inventory;
    const notes = [];
    (gain || []).forEach((id) => {
      inv[id] = (inv[id] || 0) + 1;
      const it = this.itemMap[id];
      notes.push("获得「" + (it ? it.name : id) + "」");
    });
    (consume || []).forEach((id) => {
      if (inv[id]) inv[id] -= 1;
      if (inv[id] <= 0) delete inv[id];
      const it = this.itemMap[id];
      notes.push("消耗「" + (it ? it.name : id) + "」");
    });
    if (effects) {
      Object.keys(effects).forEach((k) => {
        this.state.variables[k] = (this.state.variables[k] || 0) + effects[k];
        notes.push(k + (effects[k] >= 0 ? " +" : " ") + effects[k]);
      });
    }
    if (notes.length) this.toast(notes.join("  "));
  };

  Player.prototype.show = function (nodeId) {
    const node = this.nodeMap[nodeId];
    if (!node) {
      this._renderMissing(nodeId);
      return;
    }
    this.current = nodeId;
    // 进入节点即结算节点级道具进出
    this._applyItems(node.gain_items, node.consume_items, null);
    this._renderStage(node);
    this._renderHud();
    this._renderBottom(node);
  };

  Player.prototype._renderStage = function (node) {
    // 保留粒子 canvas，只更新其他内容
    const canvas = this.$particles;
    const src = node.media_url ? this.assetBase + node.media_url : null;
    // 先清理非 canvas 子节点
    Array.from(this.$stage.childNodes).forEach((el) => {
      if (el !== canvas) this.$stage.removeChild(el);
    });
    let mediaEl;
    if (src && node.media_type === "video") {
      mediaEl = document.createElement("video");
      mediaEl.src = src; mediaEl.autoplay = true; mediaEl.loop = true;
      mediaEl.muted = true; mediaEl.playsInline = true;
    } else if (src) {
      mediaEl = document.createElement("img");
      mediaEl.src = src; mediaEl.alt = "";
    } else {
      mediaEl = this._placeholderEl(node);
    }
    // 插到粒子 canvas 之前，保证粒子层始终在最上
    this.$stage.insertBefore(mediaEl, canvas || null);
  };

  // 无素材时的程序化占位底图（优先使用 visual_theme.scene_gradients）
  Player.prototype._placeholderEl = function (node) {
    const bg = this._pickGradient(node);
    const emoji =
      node.type === "ending" ? "🎬" :
      node.type === "minigame" ? "⚡" :
      (node.emotion_intensity || 0) > 0.75 ? "🔥" :
      (node.emotion_intensity || 0) > 0.5 ? "✨" :
      (node.emotion_intensity || 0) > 0.3 ? "🌙" : "🕊️";
    const scene = esc(node.location || (node.scene_id || "场景"));
    const tag = node.media_type === "video" ? "动态演出" : "静态画面";
    const motif = esc((((this.theme && this.theme.visual_motifs) || [])[0]) || "");
    const div = document.createElement("div");
    div.className = "mh-placeholder";
    div.style.background = bg;
    div.innerHTML = `
      <div class="mh-emoji">${emoji}</div>
      <div class="mh-ph-scene">${scene}</div>
      <div class="mh-ph-tag">${tag}</div>
      ${motif ? `<div class="mh-ph-motif">${motif}</div>` : ""}
    `;
    return div;
  };

  Player.prototype._pickGradient = function (node) {
    const grads = (this.theme && this.theme.scene_gradients) || {};
    const bucket = bucketFromEmotion(node);
    if (grads[bucket]) return grads[bucket];
    if (grads["default"]) return grads["default"];
    // 完全没有主题时的老回退：按情绪调 hue
    const e = node.emotion_intensity || 0.5;
    const hue1 = Math.round(260 - e * 220);
    const hue2 = Math.round(320 - e * 260);
    return `linear-gradient(150deg, hsl(${hue1} 60% 32%), hsl(${hue2} 55% 20%))`;
  };

  Player.prototype._renderHud = function () {
    const v = this.state.variables;
    let html = Object.keys(v)
      .map((k) => `<span class="mh-chip">${esc(k)} <b>${v[k]}</b></span>`)
      .join("");
    const inv = this.state.inventory;
    Object.keys(inv).forEach((id) => {
      const it = this.itemMap[id];
      html += `<span class="mh-chip mh-item">🎒 ${esc(it ? it.name : id)}${inv[id] > 1 ? " <b>×" + inv[id] + "</b>" : ""}</span>`;
    });
    this.$hud.innerHTML = html;
  };

  Player.prototype._renderBottom = function (node) {
    // 结局节点
    if (node.type === "ending") {
      this._renderEnding(node);
      return;
    }
    let html = "";
    if (node.character) html += `<div class="mh-speaker">${esc(node.character)}</div>`;
    const cls =
      node.type === "inner_monologue" ? " mh-inner" :
      node.type === "system" ? " mh-system" :
      node.type === "status_change" ? " mh-status" : "";
    html += `<div class="mh-textbox${cls}">${esc(node.content || "")}</div>`;
    this.$bottom.innerHTML = html;

    if (node.minigame) {
      this._renderMinigame(node);
    } else if (node.choices && node.choices.length) {
      this._renderChoices(node);
    } else {
      this._renderContinue(node);
    }
  };

  Player.prototype._renderChoices = function (node) {
    const wrap = document.createElement("div");
    wrap.className = "mh-choices";
    const self = this;
    node.choices.forEach((c, idx) => {
      const btn = document.createElement("button");
      btn.className = "mh-choice";
      const condOk = evalCond(c.requires, self.state);
      const itemsOk = (c.requires_items || []).every(
        (id) => (self.state.inventory[id] || 0) > 0
      );
      const ok = condOk && itemsOk;
      let extra = "";
      if (c.effects && Object.keys(c.effects).length) {
        extra += `<span class="mh-eff">${Object.keys(c.effects)
          .map((k) => k + (c.effects[k] >= 0 ? "+" : "") + c.effects[k])
          .join(" ")}</span>`;
      }
      if (!ok) {
        const reason = !itemsOk ? "缺道具" : renderCond(c.requires) || "未满足条件";
        extra += `<span class="mh-lock">🔒 ${esc(reason)}</span>`;
      }
      btn.innerHTML = esc(c.text) + extra;
      btn.disabled = !ok;
      btn.onclick = function () {
        self.state.taken.add(node.id + "#" + idx);
        self._applyItems(c.gain_items, c.consume_items, c.effects);
        self.show(c.goto);
      };
      wrap.appendChild(btn);
    });
    this.$bottom.appendChild(wrap);
  };

  Player.prototype._renderContinue = function (node) {
    // 无选项、非结局：顺延到下一节点（按 nodes 顺序）
    const idx = this.nodeOrder.indexOf(node.id);
    const nextId = idx >= 0 && idx + 1 < this.nodeOrder.length ? this.nodeOrder[idx + 1] : null;
    const self = this;
    const btn = document.createElement("button");
    btn.className = "mh-continue";
    if (nextId) {
      btn.textContent = "继续 ▶";
      btn.onclick = function () { self.show(nextId); };
    } else {
      btn.textContent = "▶ 完 · 重玩";
      btn.onclick = function () { self.reset(); };
    }
    this.$bottom.appendChild(btn);
  };

  Player.prototype._renderMinigame = function (node) {
    const mg = node.minigame;
    const self = this;
    const wrap = document.createElement("div");
    wrap.className = "mh-minigame";
    const label = { timed_click: "限时点击", qte: "QTE 快速反应", puzzle: "解谜" }[mg.type] || "小游戏";
    wrap.innerHTML =
      `<div class="mh-mg-hint">${label} · ${esc(mg.difficulty || "normal")} · 窗口 ${mg.window_ms}ms</div>
       <div class="mh-mg-bar"><div class="mh-mg-fill" data-mh="fill"></div></div>`;
    const btn = document.createElement("button");
    btn.className = "mh-mg-btn";
    btn.textContent = "⚡ 立即点击！";
    wrap.appendChild(btn);
    this.$bottom.appendChild(wrap);

    const fill = wrap.querySelector('[data-mh="fill"]');
    let done = false;
    const t0 = Date.now();
    const win = mg.window_ms || 800;
    // 倒计时进度条
    const timer = setInterval(function () {
      const left = Math.max(0, win - (Date.now() - t0));
      fill.style.width = (left / win) * 100 + "%";
      if (left <= 0 && !done) {
        done = true;
        clearInterval(timer);
        self.toast("挑战失败…");
        self.show(mg.on_failure || mg.on_success);
      }
    }, 30);
    btn.onclick = function () {
      if (done) return;
      done = true;
      clearInterval(timer);
      if (mg.reward) self._applyItems(null, null, mg.reward);
      self.toast("挑战成功！");
      self.show(mg.on_success);
    };
  };

  Player.prototype._matchEnding = function (node) {
    // 优先按 branch_id 匹配 endings；再按 unlock 条件筛可解锁的
    const byBranch = this.endings.filter((e) => e.branch_id && e.branch_id === node.branch_id);
    const pool = byBranch.length ? byBranch : this.endings;
    const unlocked = pool.filter((e) => evalCond(e.unlock, this.state));
    const trueEnd = unlocked.find((e) => e.is_true_ending);
    return trueEnd || unlocked[0] || pool[0] || null;
  };

  Player.prototype._renderEnding = function (node) {
    const ending = this._matchEnding(node);
    const self = this;
    const isTrue = ending && ending.is_true_ending;
    const div = document.createElement("div");
    div.className = "mh-ending" + (isTrue ? " mh-true" : "");
    div.innerHTML = `
      <div class="mh-ending-badge">${isTrue ? "★ TRUE ENDING ★" : "— 结局 —"}</div>
      <h2>${esc(ending ? ending.title : "尾声")}</h2>
      <div class="mh-ending-desc">${esc(node.content || "")}</div>
      <button class="mh-continue" data-mh="again">↺ 再玩一次</button>
    `;
    // 结局屏也复用 scene_gradients（按 ending_true/ending_bad 桶）
    const bg = this._pickGradient(node);
    const canvas = this.$particles;
    Array.from(this.$stage.childNodes).forEach((el) => {
      if (el !== canvas) this.$stage.removeChild(el);
    });
    const ph = document.createElement("div");
    ph.className = "mh-placeholder";
    ph.style.background = bg;
    ph.innerHTML = `<div class="mh-emoji">${isTrue ? "🌸" : "🎬"}</div>`;
    this.$stage.insertBefore(ph, canvas || null);

    this.$bottom.innerHTML = "";
    this.el.appendChild(div);
    this._endingEl = div;
    div.querySelector('[data-mh="again"]').onclick = function () {
      div.remove();
      self.reset();
    };
  };

  Player.prototype._renderMissing = function (id) {
    this.$bottom.innerHTML =
      `<div class="mh-textbox">⚠️ 节点缺失：${esc(id)}</div>`;
    const self = this;
    const btn = document.createElement("button");
    btn.className = "mh-continue";
    btn.textContent = "↺ 重玩";
    btn.onclick = function () { self.reset(); };
    this.$bottom.appendChild(btn);
  };

  function esc(s) {
    return String(s === null || s === undefined ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // ------------------------- 对外 API ------------------------- //
  const ManhuaPlayer = {
    mount: function (container, game, opts) {
      if (typeof container === "string") container = document.querySelector(container);
      return new Player(container, game, opts);
    },
    // 供测试/工具复用的纯函数：把 palette dict 展开成 CSS 变量名列表
    _paletteKeyToVar: paletteKeyToVar,
  };

  global.ManhuaPlayer = ManhuaPlayer;
  if (typeof module !== "undefined" && module.exports) module.exports = ManhuaPlayer;
})(typeof window !== "undefined" ? window : this);
