"""P1：分阶段（stepwise）流水线执行器 —— 支持 Human-in-the-loop 与进度回调。

P0 的 :func:`manhua_agent.graph.run_pipeline` 会一次性把整张 LangGraph 跑完，
无法在中途暂停。P1 的前端向导需要：

1. **实时进度**：每个 Agent 跑完立即上报状态；
2. **Planner 后人工介入**：Planner 产出剧情分支骨架后暂停，
   等用户在前端审阅/修改并「确认继续」，才继续跑后续 Agent。

本模块**不重写** Agent 逻辑，而是**复用** ``graph.py`` 里已经写好的节点函数
（``node_parse`` / ``node_plan`` / ``node_write`` / ``node_check`` / ``node_gamify``
/ ``node_direct`` / ``node_structure``），把它们拆成两个阶段：

    阶段 A（run_until_plan）:  parse → plan   —— 结束后暂停
    （中间：用户编辑 skeleton）
    阶段 B（run_after_plan）:  write ↔ check（重写回环）→ gamify → direct → structure

这样既保证与 P0 CLI 完全一致的生成语义，又获得暂停/续跑能力。
LangGraph 仍是 P0 CLI 的编排引擎；P1 只是换了一种「手动驱动同一批节点函数」的方式。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from .config import PipelineConfig
from .graph import (
    _State,
    node_check,
    node_direct,
    node_gamify,
    node_parse,
    node_plan,
    node_rewrite_bump,
    node_structure,
    node_write,
)
from .llm import LLMRouter
from .models import GameOutput, StorySkeleton

logger = logging.getLogger(__name__)

# 阶段划分：给前端展示的 7 个 Agent 步骤 key（顺序即展示顺序）
AGENT_STEPS: List[Dict[str, str]] = [
    {"key": "parser", "label": "解析 Agent", "desc": "抽取人设 / 世界观 / 大纲"},
    {"key": "planner", "label": "规划 Agent", "desc": "生成 MECE 剧情分支骨架"},
    {"key": "writer", "label": "写作 Agent", "desc": "把节拍写成节点正文"},
    {"key": "consistency", "label": "一致性 Agent", "desc": "查重 / 人设冲突 / 结构校验"},
    {"key": "gamification", "label": "游戏化 Agent", "desc": "挂选项 / 结局 / 道具 / 小游戏"},
    {"key": "direction", "label": "演出 Agent", "desc": "分配演出档位与场景 / BGM / CG"},
    {"key": "structurer", "label": "结构化 Agent", "desc": "合并自修复，产出 GameOutput"},
]

# 进度回调签名：progress(step_key, status, message)
#   status ∈ {"running", "done", "error"}
ProgressCB = Callable[[str, str, Optional[str]], None]


def _noop_progress(step: str, status: str, message: Optional[str]) -> None:  # pragma: no cover
    pass


@dataclass
class PipelineSession:
    """一次生成任务的可暂停会话。持有 LangGraph 的 _State 字典。"""

    config: PipelineConfig
    state: _State = field(default_factory=dict)  # type: ignore[assignment]
    router: Optional[LLMRouter] = None
    stage: str = "init"  # init → planned → finished

    # ------------------------------------------------------------------ #
    # 阶段 A：parse → plan，结束后暂停
    # ------------------------------------------------------------------ #
    def run_until_plan(self, progress: ProgressCB = _noop_progress) -> StorySkeleton:
        self.config.validate_mode()
        if self.router is None and not self.config.dry_run:
            try:
                self.router = LLMRouter()
            except Exception as exc:  # pragma: no cover
                logger.warning("无法初始化 LLMRouter，将走 dry-run：%s", exc)
                self.router = None

        self.state = {
            "config": self.config,
            "router": self.router,
            "logs": [],
            "retry_count": 0,
        }

        progress("parser", "running", None)
        self.state = node_parse(self.state)
        progress("parser", "done", _last_log(self.state))

        progress("planner", "running", None)
        self.state = node_plan(self.state)
        progress("planner", "done", _last_log(self.state))

        self.stage = "planned"
        return self.state["skeleton"]

    # ------------------------------------------------------------------ #
    # HITL：用户编辑后的 skeleton 回写
    # ------------------------------------------------------------------ #
    def apply_skeleton(self, skeleton: StorySkeleton) -> None:
        """把前端编辑过的分支骨架写回 state，供阶段 B 使用。"""
        if self.stage != "planned":
            raise RuntimeError("只能在 Planner 完成、流水线暂停时编辑分支结构")
        self.state["skeleton"] = skeleton

    # ------------------------------------------------------------------ #
    # 阶段 B：write ↔ check → gamify → direct → structure
    # ------------------------------------------------------------------ #
    def run_after_plan(self, progress: ProgressCB = _noop_progress) -> GameOutput:
        if self.stage != "planned":
            raise RuntimeError("必须先执行 run_until_plan 并确认分支结构")

        # writer ↔ consistency 重写回环（语义对齐 graph._run_sequential）
        max_retry = self.config.branch_count
        for attempt in range(max_retry + 1):
            suffix = f"（第 {attempt + 1} 次）" if attempt else ""
            progress("writer", "running", suffix or None)
            self.state = node_write(self.state)
            progress("writer", "done", _last_log(self.state))

            progress("consistency", "running", None)
            self.state = node_check(self.state)
            report = self.state["consistency"]
            if report.passed or attempt >= max_retry:
                msg = _last_log(self.state)
                if not report.passed:
                    msg = (msg or "") + "（已达重试上限，放行）"
                progress("consistency", "done", msg)
                break
            progress("consistency", "done", "检测到问题，触发重写")
            self.state = node_rewrite_bump(self.state)

        progress("gamification", "running", None)
        self.state = node_gamify(self.state)
        progress("gamification", "done", _last_log(self.state))

        progress("direction", "running", None)
        self.state = node_direct(self.state)
        progress("direction", "done", _last_log(self.state))

        progress("structurer", "running", None)
        self.state = node_structure(self.state)
        progress("structurer", "done", _last_log(self.state))

        self.stage = "finished"
        return self.state["game"]

    # ------------------------------------------------------------------ #
    # 便捷访问
    # ------------------------------------------------------------------ #
    @property
    def game(self) -> Optional[GameOutput]:
        return self.state.get("game")

    @property
    def logs(self) -> List[str]:
        return self.state.get("logs", [])


def _last_log(state: _State) -> Optional[str]:
    logs = state.get("logs", [])
    return logs[-1] if logs else None
