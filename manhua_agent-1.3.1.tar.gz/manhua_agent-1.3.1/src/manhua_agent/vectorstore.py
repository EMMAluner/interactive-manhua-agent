"""向量去重（内存版）。

产品文档 4.3 第 4 条：一致性校验 Agent 把每条支线向量化，与已有支线算相似度，
超阈值判定雷同并打回重写。

生产环境建议接入外部向量库（Milvus/FAISS/Qdrant），当前实现只依赖 numpy。
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

import numpy as np


def cosine_similarity(a: Sequence[float], b: Sequence[float]) -> float:
    va = np.asarray(a, dtype=np.float32)
    vb = np.asarray(b, dtype=np.float32)
    denom = float(np.linalg.norm(va) * np.linalg.norm(vb))
    if denom == 0.0:
        return 0.0
    return float(np.dot(va, vb) / denom)


class InMemoryVectorStore:
    """按标签追加、按余弦相似度查询。"""

    def __init__(self) -> None:
        self._items: List[Tuple[str, List[float], str]] = []
        # (label, vector, text)

    def add(self, label: str, vector: List[float], text: str = "") -> None:
        self._items.append((label, list(vector), text))

    def most_similar(
        self, vector: List[float], exclude_label: Optional[str] = None
    ) -> Tuple[Optional[str], float]:
        """返回相似度最高的 (label, score)。库为空则返回 (None, 0.0)。"""
        best_label: Optional[str] = None
        best_score = 0.0
        for label, vec, _ in self._items:
            if exclude_label and label == exclude_label:
                continue
            score = cosine_similarity(vector, vec)
            if score > best_score:
                best_score = score
                best_label = label
        return best_label, best_score

    def size(self) -> int:
        return len(self._items)

    def all_labels(self) -> List[str]:
        return [label for label, _, _ in self._items]


def hash_pseudo_embed(text: str, dim: int = 256) -> List[float]:
    """无 API 时的降级嵌入：把文本做 bag-of-chars + hash 到定长向量。

    只用于 --dry-run 或校验流程冒烟。绝不用于生产环境。
    """
    vec = np.zeros(dim, dtype=np.float32)
    for ch in text:
        idx = (hash(ch) & 0xFFFFFFFF) % dim
        vec[idx] += 1.0
    # L2 归一化
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()
