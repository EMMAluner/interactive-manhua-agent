"""P1 素材生成子包：动静混合决策 + OpenAI-Compatible 图片 / 视频生成 + 角色一致性立绘。"""

from .character_art import (
    CharacterArtResult,
    build_appearance_prompt,
    generate_character_art,
)
from .generator import (
    AssetResult,
    decide_media_types,
    generate_assets,
    generate_single_image,
)

__all__ = [
    "AssetResult",
    "decide_media_types",
    "generate_assets",
    "generate_single_image",
    "CharacterArtResult",
    "build_appearance_prompt",
    "generate_character_art",
]
