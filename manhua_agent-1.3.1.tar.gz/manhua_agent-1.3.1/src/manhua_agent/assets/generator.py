"""P1：动静混合素材生成模块。

两件事：

1. **决策**（:func:`decide_media_types`）：系统自动判断每个节点该出「视频」还是「静态图」。
   规则（产品需求）：
     - 生成视频：关键剧情转折点、高情绪强度场景（打斗 / 告别 / 反转）、章节开场 / 结尾；
     - 生成静态图：对话推进、旁白、物品展示、次要选项节点。
   为了让动态比例**可配置**，最终按 ``video_ratio``（默认 ~20%）取「视频得分」最高的
   前若干个节点标为 video，其余标为 image——因此只改配置里的 ``video_ratio`` 就能
   调整动静比例，无需改代码。

2. **生成**（:func:`generate_assets`）：按决策结果，调用「图片生成 API / 视频生成 API」
   （OpenAI-Compatible）产出素材落盘。两个 API 各有一个「填写入口」：
     - 填了（``is_ready()`` 为真）→ 启用对应素材生成；
     - 都没填 → 整个素材生成步骤跳过（节点 ``media_url`` 留空，前端回落到程序化占位底图）。
"""

from __future__ import annotations

import base64
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

from ..config import AssetEndpoint, Settings, get_settings
from ..models import GameOutput, Node

logger = logging.getLogger(__name__)

# 高情绪 / 关键场景关键词（命中即拉高视频得分）
_VIDEO_KEYWORDS = [
    "打斗", "厮杀", "对峙", "决战", "反转", "逆转", "告别", "离别", "诀别",
    "死", "生死", "牺牲", "爆发", "崩溃", "重逢", "背叛", "真相", "抉择", "坠落",
]

# 进度回调：progress(done_count, total_count, message)
AssetProgressCB = Callable[[int, int, str], None]


def _noop(done: int, total: int, msg: str) -> None:  # pragma: no cover
    pass


@dataclass
class AssetResult:
    """素材生成结果摘要。"""

    enabled: bool = False  # 是否真正启用了素材生成（至少一个 API 就绪）
    image_api: bool = False
    video_api: bool = False
    video_ratio: float = 0.0
    counts: Dict[str, int] = field(default_factory=lambda: {"image": 0, "video": 0})
    generated: Dict[str, int] = field(default_factory=lambda: {"image": 0, "video": 0})
    skipped: int = 0
    errors: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict:
        return {
            "enabled": self.enabled,
            "image_api": self.image_api,
            "video_api": self.video_api,
            "video_ratio": round(self.video_ratio, 3),
            "planned": dict(self.counts),
            "generated": dict(self.generated),
            "skipped": self.skipped,
            "errors": self.errors[:10],
        }


# --------------------------------------------------------------------------- #
# 1. 决策：每个节点该出视频还是静态图
# --------------------------------------------------------------------------- #


def _chapter_boundaries(nodes: List[Node]) -> tuple[set, set]:
    """返回 (章节开场节点 id 集合, 章节结尾节点 id 集合)。"""
    opens: set = set()
    closes: set = set()
    by_chapter: Dict[str, List[Node]] = {}
    for n in nodes:
        key = n.chapter_id or n.act_id or n.branch_id or "__default__"
        by_chapter.setdefault(key, []).append(n)
    for key, group in by_chapter.items():
        # 若有 segment_order 就用它排序，否则按出现顺序
        ordered = sorted(
            group,
            key=lambda x: (x.segment_order if x.segment_order is not None else 1_000_000),
        )
        if ordered:
            opens.add(ordered[0].id)
            closes.add(ordered[-1].id)
    return opens, closes


def _video_score(node: Node, opens: set, closes: set) -> float:
    """给节点打「适合做视频」的分数，越高越应该做视频。"""
    score = float(node.emotion_intensity)  # 基础：情绪强度

    # 关键剧情转折点：有选项 / 小游戏 / 结局
    if node.type == "ending":
        score += 0.35
    if node.type == "minigame":
        score += 0.30
    if node.choices:
        score += 0.20

    # 章节开场 / 结尾
    if node.id in opens:
        score += 0.20
    if node.id in closes:
        score += 0.20

    # 高情绪场景关键词（打斗 / 告别 / 反转 …）
    content = node.content or ""
    if any(kw in content for kw in _VIDEO_KEYWORDS):
        score += 0.25

    # 演出档位倾向
    if node.staging == "full-video":
        score += 0.30
    elif node.staging == "semi-dynamic":
        score += 0.10

    # 次要节点：对话推进 / 旁白 / 系统 / 数值变化 → 更偏静态
    if node.type in ("system", "status_change"):
        score -= 0.30
    if node.type in ("dialogue", "narration"):
        score -= 0.05

    return score


def decide_media_types(nodes: List[Node], video_ratio: float) -> Dict[str, int]:
    """就地设置每个节点的 ``media_type``（image / video），返回统计。

    先给每个节点打「视频得分」，再按 ``video_ratio`` 取得分最高的前 N 个标为 video，
    其余标为 image——这样动态比例严格受 ``video_ratio`` 控制。
    """
    if not nodes:
        return {"image": 0, "video": 0}
    video_ratio = max(0.0, min(1.0, video_ratio))
    opens, closes = _chapter_boundaries(nodes)
    scored = [(_video_score(n, opens, closes), i) for i, n in enumerate(nodes)]
    n_video = round(video_ratio * len(nodes))
    # 按得分降序，稳定选前 n_video 个
    ranked = sorted(scored, key=lambda t: t[0], reverse=True)
    video_idx = {i for _, i in ranked[:n_video]}
    for i, n in enumerate(nodes):
        n.media_type = "video" if i in video_idx else "image"
    counts = {"image": 0, "video": 0}
    for n in nodes:
        counts[n.media_type or "image"] += 1
    return counts


# --------------------------------------------------------------------------- #
# 2. 生成：调用 OpenAI-Compatible 图片 / 视频 API
# --------------------------------------------------------------------------- #


def _build_prompt(node: Node, game: GameOutput) -> str:
    """为一个节点拼素材生成 prompt。

    优先使用 Direction Agent 已经产出的 asset_prompt；若缺失，则尽量复用
    visual_theme 里的题材锚点提示词，让低成本模型也能保持统一画风。
    """
    if node.asset_prompt:
        return node.asset_prompt

    theme = game.visual_theme
    parts: List[str] = [game.title]
    if theme and theme.theme_tags:
        parts.append("/".join(theme.theme_tags[:3]))
    if node.character:
        parts.append(node.character)
    if node.location:
        parts.append(node.location)
    if node.camera:
        parts.append(node.camera)
    parts.append((node.content or "")[:60])
    if theme:
        anchor = theme.video_prompt if node.media_type == "video" else theme.image_prompt
        if anchor:
            parts.append(anchor)
        if theme.negative_prompt:
            parts.append(f"避免:{theme.negative_prompt}")
    return "；".join(p for p in parts if p)


def _safe_name(node_id: str, ext: str) -> str:
    safe = re.sub(r"[^0-9A-Za-z_\-]", "_", node_id)
    return f"{safe}.{ext}"


def generate_assets(
    game: GameOutput,
    assets_dir: Path,
    video_ratio: Optional[float] = None,
    settings: Optional[Settings] = None,
    progress: AssetProgressCB = _noop,
) -> AssetResult:
    """按决策结果生成素材落盘到 ``assets_dir``；就地把 ``media_url`` 写回节点。

    - 两个 API 都没填 → 直接跳过（只做决策，不落素材，前端用占位底图）。
    - media_url 统一写成相对路径 ``assets/<file>``，供预览与导出复用。
    """
    settings = settings or get_settings()
    ratio = settings.video_ratio if video_ratio is None else video_ratio
    nodes = game.story_tree.nodes

    result = AssetResult(
        image_api=settings.image.is_ready(),
        video_api=settings.video.is_ready(),
        video_ratio=ratio,
    )

    # 决策始终执行（前端/导出都要用 media_type 决定占位样式）
    result.counts = decide_media_types(nodes, ratio)

    if not (result.image_api or result.video_api):
        # 两个入口都没填 → 跳过素材生成步骤
        logger.info("未配置图片 / 视频生成 API，跳过素材生成步骤（仅完成动静决策）")
        result.enabled = False
        result.skipped = len(nodes)
        return result

    result.enabled = True
    assets_dir.mkdir(parents=True, exist_ok=True)
    total = len(nodes)

    for idx, node in enumerate(nodes, start=1):
        prompt = _build_prompt(node, game)
        rel: Optional[str] = None
        try:
            if node.media_type == "video" and result.video_api:
                rel = _gen_video(settings.video, prompt, node.id, assets_dir)
                if rel:
                    result.generated["video"] += 1
            # 视频没配 / 生成失败 → 回落到图片
            if rel is None and result.image_api:
                rel = _gen_image(settings.image, prompt, node.id, assets_dir)
                if rel:
                    # 回落时把类型也改成 image，保证前端渲染一致
                    node.media_type = "image"
                    result.generated["image"] += 1
        except Exception as exc:  # 单个节点失败不影响整体
            msg = f"节点 {node.id} 素材生成失败：{exc}"
            logger.warning(msg)
            result.errors.append(msg)
            rel = None

        if rel:
            node.media_url = rel
        else:
            result.skipped += 1
        progress(idx, total, f"素材 {idx}/{total}")

    return result


def _gen_image(ep: AssetEndpoint, prompt: str, node_id: str, out_dir: Path) -> Optional[str]:
    """OpenAI-Compatible 图片生成：POST /images/generations，取 b64_json 落盘。"""
    from openai import OpenAI  # 延迟导入，避免无依赖时报错

    client = OpenAI(api_key=ep.api_key, base_url=ep.base_url, http_client=_http_client())
    resp = client.images.generate(
        model=ep.model,
        prompt=prompt,
        size=ep.size,
        n=1,
        response_format="b64_json",
    )
    data = resp.data[0]
    b64 = getattr(data, "b64_json", None)
    fname = _safe_name(node_id, "png")
    fpath = out_dir / fname
    if b64:
        fpath.write_bytes(base64.b64decode(b64))
        return f"assets/{fname}"
    # 有些服务只返回 url
    url = getattr(data, "url", None)
    if url:
        _download(url, fpath)
        return f"assets/{fname}"
    return None


def generate_single_image(
    ep: AssetEndpoint,
    prompt: str,
    file_path: Path,
    seed: Optional[int] = None,
    reference_image: Optional[Path] = None,
) -> Optional[str]:
    """兼容旧调用方的单图生成入口。

    角色立绘模块仍会调用该函数。当前实现优先保证兼容性：
    - 统一复用 OpenAI-Compatible images.generate；
    - 若底层服务不支持 seed/reference image，就优雅忽略；
    - 返回值保持为相对路径字符串，方便旧代码判定是否成功。
    """
    from openai import OpenAI

    client = OpenAI(api_key=ep.api_key, base_url=ep.base_url, http_client=_http_client())
    extra = {}
    if seed is not None:
        extra["seed"] = seed
    if reference_image and reference_image.exists():
        extra["reference_image"] = str(reference_image)
    resp = client.images.generate(
        model=ep.model,
        prompt=prompt,
        size=ep.size,
        n=1,
        response_format="b64_json",
        extra_body=extra or None,
    )
    data = resp.data[0]
    b64 = getattr(data, "b64_json", None)
    if b64:
        file_path.write_bytes(base64.b64decode(b64))
        return file_path.name
    url = getattr(data, "url", None)
    if url:
        _download(url, file_path)
        return file_path.name
    return None


def _gen_video(ep: AssetEndpoint, prompt: str, node_id: str, out_dir: Path) -> Optional[str]:
    """OpenAI-Compatible 视频生成（尽力而为）。

    视频生成接口尚无统一标准，这里对常见形态做兼容尝试：
    POST {base_url}/videos/generations，期望响应里含 b64/url。
    任意失败都返回 None（由上层回落到图片或跳过），保证鲁棒性。
    """
    import json
    import urllib.request

    url = (ep.base_url or "").rstrip("/") + "/videos/generations"
    payload = json.dumps(
        {"model": ep.model, "prompt": prompt, "size": ep.size, "n": 1}
    ).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Authorization": f"Bearer {ep.api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as r:  # noqa: S310
        body = json.loads(r.read().decode("utf-8"))

    items = body.get("data") or []
    if not items:
        return None
    item = items[0]
    fname = _safe_name(node_id, "mp4")
    fpath = out_dir / fname
    if item.get("b64_json"):
        fpath.write_bytes(base64.b64decode(item["b64_json"]))
        return f"assets/{fname}"
    if item.get("url"):
        _download(item["url"], fpath)
        return f"assets/{fname}"
    return None


def _download(url: str, dest: Path) -> None:
    import urllib.request

    with urllib.request.urlopen(url, timeout=120) as r:  # noqa: S310
        dest.write_bytes(r.read())


def _http_client():
    """构造一个不读取系统代理环境变量的 httpx 客户端。

    某些环境的 no_proxy / proxy 变量含 IPv6 CIDR 等 httpx 无法解析的值，会导致
    OpenAI 客户端初始化直接抛 InvalidURL。素材生成 API 通常直连，故关闭 trust_env
    以提升健壮性；如需走代理，可自行改造此处。
    """
    try:
        import httpx

        return httpx.Client(trust_env=False, timeout=120.0)
    except Exception:  # pragma: no cover
        return None
