"""P1：角色立绘生成 + 角色一致性约束（Character Asset Agent）。

为每个主要角色建立「角色资产表」并生成多视角立绘（正面 / 侧面 / 表情变体），用于：

- 前端「角色档案」页展示与人工替换
- 节点场景图的角色形象参考（reference image）
- 导出 H5 的角色展示

一致性约束（本模块的核心设计，对应产品需求「不同节点/场景保持角色形象一致」）：

1. **锁定 prompt 模板**：每个角色首次生成时，从人设里抽取一段
   *固定的外貌 / 服装 / 发型描述词*（``Character.appearance_prompt``）。之后同一角色的
   所有立绘、所有节点场景图都复用这段词，**只替换视角 / 场景 / 动作词**，外貌词恒定不变。
2. **参考图注入**：先生成「正面全身」主图并写回 ``Character.ref_image``；随后同角色的
   侧面 / 表情立绘、以及 :mod:`~manhua_agent.assets.generator` 里的节点场景图，都会把这张
   正面主图作为 *reference image* 传给图片 API（Seedream 的 @图片参考 / IP-Adapter 语义）。
3. **固定 seed**：为每个角色分配一个稳定的随机种子（``Character.art_seed``，由角色名派生，
   可复现），若图片 API 支持 ``seed`` 则每次生成都传入，进一步稳定形象。

降级策略：``IMAGE_API_KEY`` 未填 → 跳过立绘生成（``enabled=False``），前端角色档案页显示
「未生成立绘（未配置图片 API）」占位；参考图 / seed / extra_body 被 API 拒绝时自动降级重试。
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

from ..config import AssetEndpoint, Settings, get_settings
from ..models import Character, GameOutput
from .generator import generate_single_image

logger = logging.getLogger(__name__)

# 表情变体列表（可扩展）
DEFAULT_EXPRESSIONS = ["微笑", "愤怒", "悲伤"]

# 视角列表（正面全身为主图，用作后续所有生成的参考图）
VIEWS = ["正面全身", "侧面半身"]

# 进度回调：progress(done_count, total_count, message)
CharArtProgressCB = Callable[[int, int, str], None]


def _noop(done: int, total: int, msg: str) -> None:  # pragma: no cover
    pass


@dataclass
class CharacterArtResult:
    """角色立绘生成结果摘要（含供前端角色档案页渲染的结构化数据）。"""

    enabled: bool = False
    total_characters: int = 0
    generated_images: int = 0
    skipped: int = 0
    errors: List[str] = field(default_factory=list)
    # 供前端「角色档案」页直接渲染的角色明细列表
    characters: List[Dict] = field(default_factory=list)

    def as_dict(self) -> Dict:
        return {
            "enabled": self.enabled,
            "total_characters": self.total_characters,
            "generated_images": self.generated_images,
            "skipped": self.skipped,
            "errors": self.errors[:10],
            "characters": self.characters,
        }


def _safe_char_id(name: str) -> str:
    """把角色名转为安全的文件夹/文件名。"""
    safe = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff_\-]", "_", name or "")
    return safe or "char"


def _stable_seed(name: str) -> int:
    """由角色名派生一个稳定（可复现）的随机种子，范围 [0, 2^31)。"""
    digest = hashlib.md5((name or "char").encode("utf-8")).hexdigest()
    return int(digest[:8], 16) % (2**31)


def build_appearance_prompt(character: Character) -> str:
    """为角色构造并锁定「外貌 / 服装 / 发型」固定描述词。

    该函数是角色一致性的关键：它只在角色首次进入立绘流程时执行一次，
    结果写回 ``Character.appearance_prompt`` 后即锁定，后续所有生成都复用，不再重算。

    生成逻辑：直接沿用人设 ``persona``（通常已含外貌/性格/背景一句话总结）作为外貌锚点，
    并补上角色名与定位，最后加上统一画风词。真实接入 LLM 时可在此替换为
    「让模型抽取结构化外貌词」的调用；这里保持无依赖、可 dry-run。
    """
    if character.appearance_prompt:
        return character.appearance_prompt
    parts = [f"角色：{character.name}", f"定位：{character.role}"]
    if character.persona:
        parts.append(f"外貌与人设：{character.persona}")
    # 统一画风词（固定，保证同一部作品整体风格一致）
    parts.append("统一漫画写实画风，五官/发型/服装/配色严格固定")
    character.appearance_prompt = "，".join(parts)
    return character.appearance_prompt


def _compose_prompt(appearance_prompt: str, game_title: str, *variant_words: str) -> str:
    """把「锁定外貌词（不变）」+「场景/视角/动作词（可变）」拼成最终 prompt。

    外貌词永远放在最前且逐字不变；变化的只有 ``variant_words``（视角、表情、场景、动作）。
    """
    parts = [appearance_prompt, f"作品：{game_title}"]
    parts.extend(w for w in variant_words if w)
    parts.append("高质量立绘，白色背景，适合互动漫剧游戏")
    return "，".join(p for p in parts if p)


def generate_character_art(
    game: GameOutput,
    assets_dir: Path,
    settings: Optional[Settings] = None,
    expressions: Optional[List[str]] = None,
    progress: CharArtProgressCB = _noop,
) -> CharacterArtResult:
    """为 GameOutput 中的每个主要角色建立资产表并生成多视角立绘。

    - IMAGE_API 未配置 → 跳过生成，但仍会锁定 ``appearance_prompt`` / ``art_seed``
      并回填空的角色档案（供前端展示占位）。
    - 生成的图片落盘到 ``assets_dir/characters/<char_id>/``。
    - ``Character.ref_image`` 回写为正面主图；``Character.art_views`` 记录所有视角路径。
    - 侧面 / 表情立绘均以正面主图为 reference image、并复用同一 seed，保证形象一致。
    """
    settings = settings or get_settings()
    expressions = expressions or DEFAULT_EXPRESSIONS
    result = CharacterArtResult()

    characters = game.assets.characters if game.assets else []
    # 只为主角和重要配角生成（role 含 主角/配角/反派/protagonist/main）
    main_chars = [
        c for c in characters
        if any(r in (c.role or "") for r in ("主角", "配角", "反派", "protagonist", "main"))
    ]
    if not main_chars:  # 容错：筛选后为空则对所有角色生成
        main_chars = characters

    result.total_characters = len(main_chars)
    api_ready = settings.image.is_ready()
    result.enabled = api_ready

    char_dir = assets_dir / "characters"
    if api_ready:
        char_dir.mkdir(parents=True, exist_ok=True)
    else:
        logger.info("未配置图片生成 API（IMAGE_API_KEY），跳过角色立绘生成（仅锁定 prompt 模板与 seed）")

    game_title = game.title or "互动漫剧"

    # 计算总任务数：每个角色 × (views + expressions)
    tasks_per_char = len(VIEWS) + len(expressions)
    total_tasks = max(1, result.total_characters * tasks_per_char)
    done_count = 0

    for char in main_chars:
        char_id = _safe_char_id(char.name)
        # 1) 锁定固定 prompt 模板 + 稳定 seed（无论是否配置 API 都建立资产表）
        appearance = build_appearance_prompt(char)
        if char.art_seed is None:
            char.art_seed = _stable_seed(char.name)

        if not api_ready:
            # 未配置 API：只回填档案（无图），供前端占位展示
            result.characters.append(_char_record(char, char_id, api_ready=False))
            done_count += tasks_per_char
            progress(min(done_count, total_tasks), total_tasks, f"角色资产 {char.name}（未配置图片 API）")
            continue

        char_folder = char_dir / char_id
        char_folder.mkdir(parents=True, exist_ok=True)
        ref_abs: Optional[Path] = None  # 正面主图绝对路径，作为后续生成的参考图

        # 2) 生成各视角（正面全身先行 → 作为参考图）
        for view in VIEWS:
            done_count += 1
            prompt = _compose_prompt(appearance, game_title, f"视角：{view}")
            fname = f"{char_id}_{_safe_char_id(view)}.png"
            fpath = char_folder / fname
            rel_path = f"assets/characters/{char_id}/{fname}"
            # 正面主图不带参考图（它就是基准）；侧面等带上正面主图做参考
            ref_for_this = None if "正面" in view else ref_abs
            ok = _try_gen(
                settings.image, prompt, fpath, char.art_seed, ref_for_this, result,
                f"角色 {char.name} {view} 立绘",
            )
            if ok:
                result.generated_images += 1
                char.art_views[view] = rel_path
                if "正面" in view:
                    char.ref_image = rel_path
                    ref_abs = fpath
            else:
                result.skipped += 1
            progress(done_count, total_tasks, f"角色立绘 {char.name}·{view}")

        # 3) 生成表情变体（全部以正面主图为参考图 + 同一 seed）
        for expr in expressions:
            done_count += 1
            prompt = _compose_prompt(
                appearance, game_title, "视角：正面半身特写", f"表情：{expr}"
            )
            view_key = f"表情·{expr}"
            fname = f"{char_id}_expr_{_safe_char_id(expr)}.png"
            fpath = char_folder / fname
            rel_path = f"assets/characters/{char_id}/{fname}"
            ok = _try_gen(
                settings.image, prompt, fpath, char.art_seed, ref_abs, result,
                f"角色 {char.name} 表情[{expr}] 立绘",
            )
            if ok:
                result.generated_images += 1
                char.art_views[view_key] = rel_path
            else:
                result.skipped += 1
            progress(done_count, total_tasks, f"角色立绘 {char.name}·{expr}")

        result.characters.append(_char_record(char, char_id, api_ready=True))

    return result


def _char_record(char: Character, char_id: str, api_ready: bool) -> Dict:
    """把一个角色整理成前端角色档案页需要的结构。"""
    views = [{"label": k, "url": v} for k, v in char.art_views.items()]
    return {
        "id": char_id,
        "name": char.name,
        "role": char.role,
        "persona": char.persona,
        "motivation": char.motivation,
        "appearance_prompt": char.appearance_prompt,
        "art_seed": char.art_seed,
        "ref_image": char.ref_image,
        "views": views,
        "has_art": bool(views),
        "api_ready": api_ready,
    }


def _try_gen(
    ep: AssetEndpoint,
    prompt: str,
    fpath: Path,
    seed: Optional[int],
    reference_image: Optional[Path],
    result: CharacterArtResult,
    label: str,
) -> bool:
    """调用图片 API 生成单张立绘（带参考图 + seed，失败自动降级），成功返回 True。"""
    try:
        rel = generate_single_image(
            ep, prompt, fpath, seed=seed, reference_image=reference_image
        )
        return rel is not None
    except Exception as exc:  # 单张失败不影响整体
        msg = f"{label} 生成失败：{exc}"
        logger.warning(msg)
        result.errors.append(msg)
        return False
