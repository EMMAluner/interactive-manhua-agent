"""P1：Web 后端的任务（Job）管理与后台执行。

把可暂停的 :class:`~manhua_agent.pipeline_steps.PipelineSession` 包装成带生命周期的
后台任务，供 FastAPI 通过「创建 → 轮询进度 → Planner 后确认 → 继续 → 导出」驱动。

任务状态机::

    created
      └─(后台线程) parse+plan ─▶ awaiting_confirm   ← Planner 后暂停（HITL）
                                     │ POST /confirm（可带编辑后的分支结构）
                                     ▼
                          running_after ─▶ generating_assets ─▶ finished
      任一阶段异常 ─▶ error

进度以内存字典保存，前端轮询 ``/status`` 获取。单机本地工具，无需持久化 / 并发锁复杂化，
仅用一把线程锁保护状态读写。
"""

from __future__ import annotations

import logging
import threading
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..assets import (
    AssetResult,
    CharacterArtResult,
    generate_assets,
    generate_character_art,
)
from ..config import PipelineConfig, get_settings
from ..exporter import ExportResult, export_game
from ..models import GameOutput, StorySkeleton
from ..pipeline_steps import AGENT_STEPS, PipelineSession

logger = logging.getLogger(__name__)


@dataclass
class Job:
    id: str
    config: PipelineConfig
    base_dir: Path
    status: str = "created"
    steps: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    asset_progress: Dict[str, Any] = field(
        default_factory=lambda: {"done": 0, "total": 0, "message": ""}
    )
    char_art_progress: Dict[str, Any] = field(
        default_factory=lambda: {"done": 0, "total": 0, "message": ""}
    )
    skeleton: Optional[StorySkeleton] = None
    game: Optional[GameOutput] = None
    asset_result: Optional[AssetResult] = None
    char_art_result: Optional[CharacterArtResult] = None
    export_result: Optional[ExportResult] = None
    error: Optional[str] = None
    logs: List[str] = field(default_factory=list)
    session: Optional[PipelineSession] = None

    @property
    def assets_dir(self) -> Path:
        return self.base_dir / "assets"

    @property
    def zip_path(self) -> Path:
        return self.base_dir / "game.zip"


class JobManager:
    """内存级任务管理器（单机本地服务）。"""

    def __init__(self, root: Optional[Path] = None) -> None:
        self.root = Path(root or "output/webruns")
        self.root.mkdir(parents=True, exist_ok=True)
        self._jobs: Dict[str, Job] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ #
    def create(self, config: PipelineConfig) -> Job:
        job_id = uuid.uuid4().hex[:12]
        base = self.root / job_id
        base.mkdir(parents=True, exist_ok=True)
        job = Job(id=job_id, config=config, base_dir=base)
        # 初始化 7 个步骤为 pending
        for step in AGENT_STEPS:
            job.steps[step["key"]] = {
                "label": step["label"],
                "desc": step["desc"],
                "status": "pending",
                "message": None,
            }
        with self._lock:
            self._jobs[job_id] = job
        # 后台线程跑到 Planner 暂停
        threading.Thread(target=self._run_plan_phase, args=(job,), daemon=True).start()
        return job

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock:
            return self._jobs.get(job_id)

    # ------------------------------------------------------------------ #
    def _progress(self, job: Job):
        def cb(step_key: str, status: str, message: Optional[str]) -> None:
            with self._lock:
                if step_key in job.steps:
                    job.steps[step_key]["status"] = status
                    if message:
                        job.steps[step_key]["message"] = message
        return cb

    def _run_plan_phase(self, job: Job) -> None:
        try:
            with self._lock:
                job.status = "running_plan"
            session = PipelineSession(config=job.config)
            job.session = session
            skeleton = session.run_until_plan(self._progress(job))
            with self._lock:
                job.skeleton = skeleton
                job.logs = list(session.logs)
                job.status = "awaiting_confirm"
        except Exception as exc:  # pragma: no cover
            self._fail(job, exc)

    def confirm(self, job: Job, edited_skeleton: Optional[StorySkeleton]) -> None:
        """用户确认（可带编辑）后，启动后续阶段。"""
        if job.status != "awaiting_confirm":
            raise RuntimeError(f"任务当前状态为 {job.status}，无法确认继续")
        if edited_skeleton is not None and job.session is not None:
            job.session.apply_skeleton(edited_skeleton)
            with self._lock:
                job.skeleton = edited_skeleton
        threading.Thread(target=self._run_after_phase, args=(job,), daemon=True).start()

    def _run_after_phase(self, job: Job) -> None:
        try:
            with self._lock:
                job.status = "running_after"
            assert job.session is not None
            game = job.session.run_after_plan(self._progress(job))

            # 素材生成阶段（动静混合）
            with self._lock:
                job.status = "generating_assets"
                job.logs = list(job.session.logs)
            settings = get_settings()
            ratio = job.config.video_ratio
            if ratio is None:
                ratio = settings.video_ratio

            # 阶段 1：角色立绘 + 一致性资产表（先于节点场景图，建立参考图 / seed）
            with self._lock:
                job.status = "generating_characters"

            def char_cb(done: int, total: int, msg: str) -> None:
                with self._lock:
                    job.char_art_progress = {"done": done, "total": total, "message": msg}

            char_art_result = generate_character_art(
                game,
                job.assets_dir,
                settings=settings,
                progress=char_cb,
            )
            with self._lock:
                job.char_art_result = char_art_result

            # 阶段 2：节点场景素材（动静混合，复用角色参考图 / seed 保持形象一致）
            with self._lock:
                job.status = "generating_assets"

            def asset_cb(done: int, total: int, msg: str) -> None:
                with self._lock:
                    job.asset_progress = {"done": done, "total": total, "message": msg}

            asset_result = generate_assets(
                game,
                job.assets_dir,
                video_ratio=ratio,
                settings=settings,
                progress=asset_cb,
            )
            with self._lock:
                job.game = game
                job.asset_result = asset_result
                job.status = "finished"
        except Exception as exc:  # pragma: no cover
            self._fail(job, exc)

    def export(self, job: Job) -> ExportResult:
        if job.game is None:
            raise RuntimeError("任务尚未完成，无法导出")
        result = export_game(job.game, job.zip_path, assets_dir=job.assets_dir)
        with self._lock:
            job.export_result = result
        return result

    # ------------------------------------------------------------------ #
    def characters(self, job: Job) -> List[Dict[str, Any]]:
        """返回角色档案列表（供前端「角色档案」页渲染）。

        优先用立绘阶段产出的结构化明细；若还没跑到该阶段，则从 game.assets.characters 兜底。
        """
        with self._lock:
            if job.char_art_result is not None:
                return list(job.char_art_result.characters)
            if job.game is not None and job.game.assets is not None:
                from ..assets.character_art import _char_record, _safe_char_id
                return [
                    _char_record(c, _safe_char_id(c.name), api_ready=False)
                    for c in job.game.assets.characters
                ]
            return []

    def replace_character_image(
        self, job: Job, char_id: str, view: str, data: bytes, ext: str = "png"
    ) -> Dict[str, Any]:
        """人工替换某个角色某个视角的立绘：把上传的图片落盘并回写资产表。

        - ``char_id``：角色安全 ID（``_safe_char_id`` 生成）；
        - ``view``：视角名（如「正面全身」「表情·微笑」），空则默认替换正面主图；
        - 返回更新后的该角色档案记录。
        """
        from ..assets.character_art import _char_record, _safe_char_id

        if job.game is None or job.game.assets is None:
            raise RuntimeError("任务尚未生成角色，无法替换立绘")

        target = None
        for c in job.game.assets.characters:
            if _safe_char_id(c.name) == char_id:
                target = c
                break
        if target is None:
            raise KeyError(f"未找到角色 {char_id}")

        view = view or "正面全身"
        safe_ext = (ext or "png").lstrip(".").lower()
        if safe_ext not in ("png", "jpg", "jpeg", "webp", "gif"):
            safe_ext = "png"
        folder = job.assets_dir / "characters" / char_id
        folder.mkdir(parents=True, exist_ok=True)
        fname = f"{char_id}_{_safe_char_id(view)}_custom.{safe_ext}"
        fpath = folder / fname
        fpath.write_bytes(data)
        rel = f"assets/characters/{char_id}/{fname}"

        with self._lock:
            target.art_views[view] = rel
            if "正面" in view or not target.ref_image:
                target.ref_image = rel
            # 同步刷新 char_art_result 里的对应记录
            if job.char_art_result is not None:
                new_rec = _char_record(target, char_id, api_ready=True)
                found = False
                for i, rec in enumerate(job.char_art_result.characters):
                    if rec.get("id") == char_id:
                        job.char_art_result.characters[i] = new_rec
                        found = True
                        break
                if not found:
                    job.char_art_result.characters.append(new_rec)
            return _char_record(target, char_id, api_ready=True)

    # ------------------------------------------------------------------ #
    def _fail(self, job: Job, exc: Exception) -> None:
        tb = traceback.format_exc()
        logger.error("Job %s 失败：%s\n%s", job.id, exc, tb)
        with self._lock:
            job.status = "error"
            job.error = f"{type(exc).__name__}: {exc}"

    # ------------------------------------------------------------------ #
    def status_dict(self, job: Job) -> Dict[str, Any]:
        with self._lock:
            d: Dict[str, Any] = {
                "job_id": job.id,
                "status": job.status,
                "steps": [
                    {"key": k, **v} for k, v in job.steps.items()
                ],
                "asset_progress": dict(job.asset_progress),
                "char_art_progress": dict(job.char_art_progress),
                "error": job.error,
                "logs": list(job.logs),
                "has_skeleton": job.skeleton is not None,
                "has_game": job.game is not None,
            }
            if job.asset_result is not None:
                d["asset_result"] = job.asset_result.as_dict()
            if job.char_art_result is not None:
                d["char_art_result"] = job.char_art_result.as_dict()
            if job.export_result is not None:
                d["export_result"] = job.export_result.as_dict()
            return d
